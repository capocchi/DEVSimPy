__all__ = [	"MasterModel",
					"DomainBehavior",
					"DomainStructure",
					"Object"
			]

from DomainInterface.DomainBehavior import *
from DomainInterface.DomainStructure import *
