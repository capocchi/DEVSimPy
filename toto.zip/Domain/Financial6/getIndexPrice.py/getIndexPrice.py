# -*- coding: utf-8 -*-

import sys

from iexfinance import Stock
tsla = Stock(sys.argv[1])
print(tsla.get_price())
