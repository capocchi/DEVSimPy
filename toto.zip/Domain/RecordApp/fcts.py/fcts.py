import pymongo
import random
from datetime import datetime, timedelta
import pandas as pd 

StatusValue = ['Received','Pending','Incomplete']

def getDF(msg):

	D = {'CHW':[],'Client':[],'WhenCallMade':[],'Duration':[],'Response':[]}

	for d in msg:
		#d = gen_call()
		D['CHW'].append(d['chw'])
		D['Client'].append(d['first_name'])
		D['WhenCallMade'].append(d['date_time'])
		D['Duration'].append(d['duration'])
		D['Response'].append(d['response'])

	return pd.DataFrame(D)

def getClientIDs(df):
  for ID in set(df['Client']):
  	yield ID

def getNumTries(df,ID):
  dfcol = df.loc[df['Client'] == ID]
  return dfcol.shape[0]

def listNumTries(df):
    return [[ID,getNumTries(df,ID)] for ID in getClientIDs(df)]

def getNumTriesIfReceived(df,ID):
    dfcol = df.loc[(df['Client'] == ID) & (df['Response'] == StatusValue[0])]
    return dfcol.shape[0]

def getNumTriesIfIncomplete(df,ID):
    dfcol = df.loc[(df['Client'] == ID) & (df['Response'] == StatusValue[2])]
    return dfcol.shape[0]

def getResult(df,ID):
    acc = getNumTriesIfReceived(df,ID)
    dec = getNumTriesIfIncomplete(df,ID)
    if acc > 0 :
        return [StatusValue[0],getNumTries(df,ID)]
    if dec > 0:
        return [StatusValue[2],getNumTries(df,ID)]
    else:
        return [StatusValue[1],getNumTries(df,ID)]

def getResults(df):
    return [[ID,getResult(df,ID)] for ID in getClientIDs(df)]

def getRates(df):
    NumOnFirstTry =0
    NumTriesToSuccess = 0
    NumTriesToFail = 0
    TotalTries = 0
    LongestTry = 0
    for ID in getClientIDs(df):
        resi = getResult(df,ID)
        TotalTries= TotalTries+resi[1]
        if LongestTry < resi[1]:
            LongestTry = resi[1]
        if resi[1]==2:
            NumOnFirstTry = NumOnFirstTry+1
        if resi[0]  == StatusValue[0]:
            NumTriesToSuccess = NumTriesToSuccess+resi[1]
        else:
            NumTriesToFail = NumTriesToFail + resi[1]
    return len(list(getClientIDs(df))),TotalTries,NumOnFirstTry,NumTriesToSuccess,NumTriesToFail,LongestTry

