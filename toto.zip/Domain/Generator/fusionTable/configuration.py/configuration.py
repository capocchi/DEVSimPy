# -*- coding: utf-8 -*-

#Author : Bastien POGGI
#Mail : bpoggi@univ-corse.fr
#Corporation : University Of Corsica Laboratory SPE7
#Description : The library to get data from Google Fusion Table
#Date : 2010-09-30

login = "bpoggi@univ-corse.fr"
password = "devsimpy2012"
