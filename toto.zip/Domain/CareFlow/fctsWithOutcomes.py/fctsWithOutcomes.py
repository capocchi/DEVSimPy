# -*- coding: utf-8 -*-

import pandas as pd 

StatusValue = ['failed','canceled','busy','no-answer','answer-voicemail','answer-by-client']

def getDF(msg):

	D = {'Client':[],'WhenCallMade':[],'Duration':[],'Response':[]}

	for d in msg:
		#d = gen_call()
		D['Client'].append(d['client_uuid'])
		D['WhenCallMade'].append(d['timestamp'])
		D['Duration'].append(d['duration'])
		D['Response'].append(d['outcome'].lower())

	return pd.DataFrame(D)

def getClientIDs(df):
	for ID in set(df['Client']):
		yield ID

def getNumTries(df,ID):
	dfcol = df.loc[df['Client'] == ID]
	return dfcol.shape[0]

def listNumTries(df):
	return [[ID,getNumTries(df,ID)] for ID in getClientIDs(df)]

def getNumTriesIfReceived(df,ID):
	dfcol1 = df.loc[(df['Client'] == ID) & (df['Response'] == StatusValue[4]) ]
	dfcol2 = df.loc[(df['Client'] == ID) & (df['Response'] == StatusValue[5]) ]
	return dfcol1.shape[0]+dfcol2.shape[0]

def getNumTriesIfIncomplete(df,ID):
	dfcol1 = df.loc[(df['Client'] == ID) & (df['Response'] == StatusValue[2])]
	dfcol2 = df.loc[(df['Client'] == ID) & (df['Response'] == StatusValue[3])]
	return dfcol1.shape[0]+dfcol2.shape[0]

def getResult(df,ID):
	acc = getNumTriesIfReceived(df,ID)
	dec = getNumTriesIfIncomplete(df,ID)
	if acc > 0 :
		return ["Accepted",getNumTries(df,ID)]
	if dec > 0:
		return ["Declined",getNumTries(df,ID)]
	else:
		return ["Pending",getNumTries(df,ID)]

def getResults(df):
	return [[ID,getResult(df,ID)] for ID in getClientIDs(df)]

def getRatesOutcome(df):
	NumOnFirstTry =0
	NumTriesToSuccess = 0
	NumTriesToFail = 0
	TotalTries = 0
	LongestTry = 0
	for ID in getClientIDs(df):
		resi = getResult(df,ID)
		TotalTries= TotalTries+resi[1]
		if LongestTry < resi[1]:
			LongestTry = resi[1]
		if resi[1]==2:
			NumOnFirstTry = NumOnFirstTry+1
		if resi[0] == "Accepted":
			NumTriesToSuccess = NumTriesToSuccess+resi[1]
		else:
			NumTriesToFail = NumTriesToFail + resi[1]
	return len(list(getClientIDs(df))),TotalTries,NumOnFirstTry,NumTriesToSuccess,NumTriesToFail,LongestTry

if __name__ == '__main__':
	
	import pymongo
	import pprint

	#connect to your Mongo DB database
	client = pymongo.MongoClient("mongodb+srv://rtsync:rtsync@cluster0.jngd3.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")

	#get the database name
	db = client.get_database('total_call_events')
	#get the particular collection that contains the data
	records = db.register
	calls = db.calls

	#get all calls in list
	v = list(calls.find({}))

	#get dataframe
	df = getDF(v)

	# get rates
	out = getRatesOutcome(df)

	#get all informations to display
	nbClients,TotalTries,NumOnFirstTry,NumTriesToSuccess,NumTriesToFail,LongestTry=out

	# SuccessProbOnFirstTry
	# SuccessProb
	# recommandedMaxofAttempts
	SuccessProbOnFirstTry = "%.2f"%(100*float(NumOnFirstTry)/TotalTries)
	SuccessProb = "%.2f"%(100*float(NumTriesToSuccess)/TotalTries)
	recommandedMaxofAttempts = "%d"%(round(1+1/(float(SuccessProb)/100.0)))	

	out = {'nbClients':nbClients,
			'TotalTries':TotalTries, 
			'NumOnFirstTry':NumOnFirstTry, 
			'NumTriesToSuccess':NumTriesToSuccess, 
			'NumTriesToFail':NumTriesToFail,
			'LongestTry':LongestTry,
			'SuccessProbOnFirstTry':SuccessProbOnFirstTry,
			'SuccessProb':SuccessProb,
			'recommandedMaxofAttempts':recommandedMaxofAttempts}
		
	pprint.pprint(out)