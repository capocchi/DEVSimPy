import requests, json, pprint

OAUTH_TOKEN_ENDPOINT="https://iam-dev.nicheaim.com/auth/realms/ocph/protocol/openid-connect/token"
CLIENT_SECRET="f8a233be-54d0-42bf-8618-91ea9e324ba9"
CLIENT_ID="cloud-functions"

grant_type = 'client_credentials'
body_params = {'grant_type' : grant_type}

response = requests.post(OAUTH_TOKEN_ENDPOINT, data=body_params, auth = (CLIENT_ID, CLIENT_SECRET)) 

token_raw = json.loads(response.text)
token = token_raw["access_token"]

BASE_URL="https://rtsynccareflow-vnirmg4f6q-uc.a.run.app"

headers = {"Authorization": "Bearer {}".format(token)}
r = requests.get(url=BASE_URL+'/call-event', headers=headers)
pprint.pprint(r.text)