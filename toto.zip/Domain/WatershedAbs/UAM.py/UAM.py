# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          <filename.py>
 Model:         <describe model>
 Authors:       <your name>
 Organization:  <your organization>
 Date:          <yyyy-mm-dd>
 License:       <your license>
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior

### Model class ----------------------------------------------------------------
class UAM1(DomainBehavior):
	''' DEVS Class for UAM1 model
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.state = {	'status': 'IDLE', 'sigma':INFINITY}

		self.msgL = [None]*3

	def extTransition(self):
		''' DEVS external transition function.
		'''
		for i in range(3):
			msg = self.peek(self.IPorts[i])
			if msg:
				self.msgL[i]=msg

		if not None in self.msgL:
			self.state['sigma'] = 0
			self.state['status'] = 'SENDING'
		else:
			self.state['sigma'] -= self.elapsed

	def outputFnc(self):
		''' DEVS output function.
		'''
		from DomainInterface.Object import Message
		val = sum(map(lambda a: a.value[0], self.msgL))
		self.poke(self.OPorts[0], Message([val, 0,0], self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.state['sigma'] = INFINITY
		self.state['status'] = 'IDLE'
		self.msgL = [None]*3

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.state['sigma']

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
