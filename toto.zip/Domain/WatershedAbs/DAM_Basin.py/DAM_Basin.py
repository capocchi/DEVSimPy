# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		AtomicModel.py
 Model description:     <description>
 Authors:       		capocchi_l
 Organization:  		<your organization>
 Current date & time:   2018-12-10 10:49:17.503000
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class AtomicModel(DomainBehavior):
	''' DEVS Class for the model AtomicModel
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.initPhase('IDLE',INFINITY)
		self.msgL = [None]*2
		self.cpt = 0

	def extTransition(self):
		''' DEVS external transition function.
		'''
		for i in range(2):
			msg = self.peek(self.IPorts[i])
			if msg:
				self.msgL[i]=msg

		if not None in self.msgL:
			self.state['sigma'] = 0
			self.state['status'] = 'SENDING'
		else:
			self.state['sigma'] -= self.elapsed

	def outputFnc(self):
		''' DEVS output function.
		'''
		### TODO: with Temp horaires.csv
		#if self.msgL[0]:
		coef_inf = 1
		coef_sup = 2
		val = float(self.msgL[0].value[0]) + (-self.cpt*coef_inf) if self.cpt > 12 else float(self.msgL[0].value[0]) + (self.cpt*coef_sup)
		#val = float(self.msgL[0].value[0])
		self.poke(self.OPorts[0], Message([float(val),0,0], self.timeNext))
		#if self.msgL[1]:
		self.poke(self.OPorts[1], Message([float(self.msgL[1].value[0]/24.0),0,0], self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		### DEVS internal transition function
		self.cpt +=1
		if self.cpt == 24:
			self.state['status'] = 'IDLE'
			self.state['sigma'] = INFINITY
			self.msgL = [None]*2
			self.cpt = 0
		else:
			self.state['status'] = 'SENDING'
			self.state['sigma'] = 0.0416

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
