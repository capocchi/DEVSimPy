# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		AtomicModel.py
 Model description:     <description>
 Authors:       		capocchi_l
 Organization:  		<your organization>
 Current date & time:   2018-12-10 10:49:17.561000
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class AtomicModel(DomainBehavior):
	''' DEVS Class for the model AtomicModel
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.initPhase('IDLE',INFINITY)

		self.values = []

	def extTransition(self):
		''' DEVS external transition function.
		'''
		msg = self.peek(self.IPorts[0])
		self.values.append(float(msg.value[0]))

		if len(self.values) == 24:
			self.holdIn('SEND',0)
		else:
			self.passivateIn('IDLE')

	def outputFnc(self):
		''' DEVS output function.
		'''
		return self.poke(self.OPorts[0], Message([sum(self.values)], self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		if self.phaseIs('SEND'):
			self.values = []
		self.passivateIn('IDLE')

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
