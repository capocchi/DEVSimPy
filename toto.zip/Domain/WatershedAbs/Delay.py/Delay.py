# -*- coding: utf-8 -*-

"""
Name: Delay.py
Brief descritpion:
Author(s): L. Capocchi and JF. Santucci <{capocchi, santucci}@univ-corse.fr>
Version:  1.0
Last modified: 2014.11.24
GENERAL NOTES AND REMARKS:
GLOBAL VARIABLES AND FUNCTIONS:
"""

from __future__ import with_statement

from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

import os.path

#    ======================================================================    #
class Delay(DomainBehavior):
    """
    """

    def __init__(self, coef=0.0, d1=100, d2=250):
        """
            @param coef : time coef
        """

        DomainBehavior.__init__(self)

        ### local copy
        self.coef = coef
        self.d1 = d1
        self.d2 = d2
        self.state = {'status': 'IDLE', 'sigma': INFINITY}

        self.buffer = []

    def intTransition(self):
        """
        """
        
        self.state['sigma'] = INFINITY
        self.state['status'] = 'IDLE'

    def outputFnc(self):
        """
        """
        if self.coef != 0 and int(self.timeNext)%int(self.coef) == 0 and len(self.buffer) > 0:
            
            self.poke(self.OPorts[0], Message([sum(map(lambda a: a.value[0],self.buffer)),0,0], self.timeNext))
            self.buffer = []
        else:
            self.poke(self.OPorts[0], self.msg)

    def extTransition(self):
        """
        """
      
        self.msg = self.peek(self.IPorts[0])
        if self.timeLast > self.d1 and self.timeLast < self.d2:
           self.buffer.append(self.msg)

        self.state['sigma'] = 0
        self.state['status'] == 'BUZY'
        
      
    def timeAdvance(self): return self.state['sigma']

    def __str__(self): return self.__class__.__name__
