# -*- coding: utf-8 -*-

"""
Name: Estimator.py
Brief descritpion:
Author(s): L. Capocchi and JF. Santucci <{capocchi, santucci}@univ-corse.fr>
Version:  1.0
Last modified: 2014.11.24
GENERAL NOTES AND REMARKS:
GLOBAL VARIABLES AND FUNCTIONS:
"""

from __future__ import with_statement

from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

import os.path

#    ======================================================================    #
class Estimator(DomainBehavior):
	"""
	"""

	def __init__(self, coef=[0,0,0]):
		DomainBehavior.__init__(self)

		### local copy
		self.state = {'status': 'IDLE', 'sigma': INFINITY }
		self.coef = coef

		self.msgL = [None]*100

	def intTransition(self):
		"""
		"""
		self.state['status'] = 'IDLE'
		self.state['sigma'] = INFINITY

	def outputFnc(self):
		"""
		"""

		for i,p in enumerate(self.OPorts):
			val = sum(self.msgL)*self.coef[i]
			try:
				self.poke(p, Message([val,0,0], self.timeNext))
			except:pass
		
	def extTransition(self):
		"""
		"""

		if len(self.msgL) > len(self.IPorts):
			self.msgL = self.msgL[0:len(self.IPorts)]
		
		for i in range(len(self.IPorts)):
			msg = self.peek(self.IPorts[i])
			if msg:
				self.msgL[i]=msg.value[0]

		if not None in self.msgL:
			self.state['sigma'] = 0
			self.state['status'] = 'SENDING'
		else:
			self.state['sigma'] -= self.elapsed

	def timeAdvance(self): return self.state['sigma']

	def __str__(self): return self.__class__.__name__
