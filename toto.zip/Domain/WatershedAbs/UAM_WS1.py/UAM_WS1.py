# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          <filename.py>
 Model:         <describe model>
 Authors:       <your name>
 Organization:  <your organization>
 Date:          <yyyy-mm-dd>
 License:       <your license>
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class UAM1(DomainBehavior):
	''' DEVS Class for UAM1 model
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.initPhase('IDLE',INFINITY)
		self.msgL = [] #[None]*6

	def extTransition(self):
		''' DEVS external transition function.
		'''
		for i in range(len(self.IPorts)):
			msg = self.peek(self.IPorts[i])
			if msg:
				self.msgL.append(msg.value[0])

		#if None in self.msgL:
		#	self.state['sigma'] -= self.elapsed
		#else:
		if len(self.msgL) == len(self.IPorts):
			self.holdIn('SENDING',0)
		else:
			self.passivate()

	def outputFnc(self):
		''' DEVS output function.
		'''		
		val = sum(self.msgL) #map(lambda a: a.value[0], filter(lambda a: a is not None, self.msgL)))
		self.msgL = []
		return self.poke(self.OPorts[0], Message([val, 0,0], self.timeNext))
		
	def intTransition(self):
		''' DEVS internal transition function.
		'''
		#self.msgL = [None]*len(self.IPorts)
		self.passivate()

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.state['sigma']

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
