# -*- coding: utf-8 -*-

"""
Name: Distributor.py
Brief descritpion:
Author(s): L. Capocchi and JF. Santucci <{capocchi, santucci}@univ-corse.fr>
Version:  1.0
Last modified: 2014.11.24
GENERAL NOTES AND REMARKS:
GLOBAL VARIABLES AND FUNCTIONS:
"""

from __future__ import with_statement

from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

import os.path

#    ======================================================================    #
class Distributor(DomainBehavior):
    """
    """

    def __init__(self, percent=[0.33,0.33,0.33,0.33,0.33,0.33]):
        DomainBehavior.__init__(self)

        ### local copy
        self.state = {'status': 'IDLE', 'sigma': INFINITY }

        self.percent = percent
        
        self.msg = None

    def intTransition(self):
        """
        """
        self.state['sigma'] = INFINITY
        self.state['status'] = 'IDLE'

    def outputFnc(self):
        """
        """
        
        for i in range(len(self.OPorts)):
          val = self.msg.value[0]*self.percent[i]
          self.poke(self.OPorts[i], Message([val,0,0], self.timeNext))

    def extTransition(self):
        """
        """
        self.msg = self.peek(self.IPorts[0])

        self.state['status'] = 'BUZY'
        self.state['sigma'] = 0

    def timeAdvance(self): return self.state['sigma']

    def __str__(self): return self.__class__.__name__
