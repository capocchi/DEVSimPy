# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          <filename.py>
 Model:         <describe model>
 Authors:       <your name>
 Organization:  <your organization>
 Date:          <yyyy-mm-dd>
 License:       <your license>
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior


### Model class ----------------------------------------------------------------
class DAM1(DomainBehavior):
	''' DEVS Class for DAM1 model
	'''

	def __init__(self, percent1=0.5, percent2=0.3, percent3=0.2):
		''' Constructor.
			@param percent1 : ruissellement
			@param percent2 : superficiel
			@param percent3 : geologique
		'''
		DomainBehavior.__init__(self)

		self.percent1 = percent1
		self.percent2 = percent2
		self.percent3 = percent3

		self.state = {	'status': 'IDLE', 'sigma':INFINITY}
		self.msg1 = None
		self.msg2 = None
		self.msg3 = None
		self.msg4 = None

		self.msgL=[None,None]

	def extTransition(self):
		''' DEVS external transition function.
		'''
		from DomainInterface.Object import Message

		for i in range(2):
			msg = self.peek(self.IPorts[i])
			if msg:
				self.msgL[i]=msg

		if not None in self.msgL:
			val = float(self.msgL[0].value[0])
			self.msg1 = Message([self.percent1*val, 0.0, 0.0], self.timeNext)
			self.msg2 = Message([self.percent2*val, 0.0, 0.0], self.timeNext)
			self.msg3 = Message([self.percent3*val, 0.0, 0.0], self.timeNext)
			self.msg4 = Message([float(self.msgL[1].value[0]), 0.0, 0.0], self.timeNext)
			self.state['sigma'] = 0
			self.state['status'] = 'SENDING'
		else:
			self.state['sigma'] -= self.elapsed
		
	def outputFnc(self):
		''' DEVS output function.
		'''
		self.poke(self.OPorts[0], self.msg1)
		self.poke(self.OPorts[1], self.msg2)
		self.poke(self.OPorts[2], self.msg3)
		self.poke(self.OPorts[3], self.msg4)

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.state['sigma'] = INFINITY

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.state['sigma']

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
