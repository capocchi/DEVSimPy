# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		LogicalBehavior3.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2020-10-27 10:27:31.379965
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

import random
import pprint

import fct2
import importlib

### Model class ----------------------------------------------------------------
class LogicalBehavior3(DomainBehavior):
	''' DEVS Class for the model LogicalBehavior3
	'''

	def __init__(self, direct_conflict_flag=True,indirect_conflict_flag=True, N=10):
		''' Constructor.

			@param eca_inputs_def: possible state of device attached to the device (maybe can be defined in the eca spec)
			@param eca_inputs_def: the eca condition rule to detect conflict
			@param features: association between features and inputs definition
			@param threshold: delta considered for the direct conflict
			@param direct_conflict_flag: detect direct conflict f true
			@param indirect_conflict_flag: detect indirect conflict f true
			@param rules_filename: file that contains all of the app rules (specific to RemedIoT)
			@param N: size of the loop used to initialize the state of the devices
		'''

		importlib.reload(fct2)

		DomainBehavior.__init__(self)

		eca_states_def = {"Robot":("Stopped","Cleaning","Resumed","Paused"), "TV":("Muted", "Unmuted")} 
		eca_inputs_def='Input(1)=("STOP","CLEAN", "RESUME", "PAUSE") Input(2)=("MUTE","UNMUTE") Input(3)=("MUTE","UNMUTE")'
		features={"NOISE":[(('TV,Unmuted','Robot,Cleaning'),{'3,UNMUTE', '1,CLEAN', '2,MUTE'})]}
		### TODO: to deduce from state variables above
		### inputs is the dict used to make a relation between the app and the events and the target device which have in management
		self.INPUTS = {	'1':({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
				'2':({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
				'3':({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
		}
		
		self.state_event_map = {"Robot" : {"STOP":"Stopped", "CLEAN":"Cleaning", "RESUME":"Resumed", "PAUSE":"Paused"}, "TV":{"MUTE":"Muted", "UNMUTE":"Unmuted"}}
		
		### local copy
		self.eca_inputs_def = eca_inputs_def
		self.eca_states_def = eca_states_def
		self.features = features

		self.ts = 1
		
		self.direct_conflict_flag = direct_conflict_flag
		self.indirect_conflict_flag = indirect_conflict_flag

		### output def
		
		nbActuators = ['Robot','TV']
		self.out = dict(zip(nbActuators, range(len(nbActuators))))

		self.app = {}

		self._conflictcond = fct2.getPythonConflictCond(self.eca_inputs_def)

		### list of possible direct and indirect conflicts
		self.total_conflicts = set()
		self.total_direct_conflicts = set()
		self.total_indirect_conflicts = set()

		### try with several inital states generated randomly
		for i in range(N):
			self.current_states = dict((app,random.choice(states)) for app,states in self.eca_states_def.items())
			self.total_conflicts.update(fct2.getConflictList(self.INPUTS,self.features,self.current_states,0.0))

		### populate the direct and indirect
		for c in self.total_conflicts:
			if 'direct' == c[0]:
				self.total_direct_conflicts.add(c)
			else:
				self.total_indirect_conflicts.add(c)

		self.nb_total_direct_conflicts = len(self.total_direct_conflicts)
		self.nb_total_indirect_conflicts = len(self.total_indirect_conflicts)

		### number of app
		print(f"Number of apps {len(self.INPUTS)}")

		### number of direct conflicts
		print(f"Number of direct conflicts {len(self.total_direct_conflicts)}")

		### number of indirect conflicts
		print(f"Number of indirect conflicts {len(self.total_indirect_conflicts)}")

#		pprint.pprint(self.total_conflicts)

		self.initPhase('IDLE',INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''

		a = len(self.total_direct_conflicts) > 0
		b = len(self.total_indirect_conflicts) > 0 
		
		### peek message
		msg = self.peek(self.IPorts[0], *args)
		v = self.getMsgValue(msg)

		### update the dict of apps
		self.app = dict(v)

		### conflicts detection
		### TODO conflictcond process
#		d = self._conflictcond
		
		self.D = {}
		
		### search direct conflicts
		directs = fct2.getDirectConflict(v,self.ts)

		### if direct conflicts have been founded
		if directs:
			### resolution rule: send to a device, the last one app event with the first command (('direct', ('216/ON', '85/OFF'), 'light') -> ('light',ON)) 
			for c in directs:
				self.D.update({c[-1]:c[1][0].split('/')[1]})
			
			if a:
				self.total_direct_conflicts -= directs
		
		
		indirects = fct2.getIndirectConflict(v,self.features, self.current_states)

		### if indirect conflicts have been founded
		if indirects:
			a = sorted(set([c[1] for c in indirects]))
			for i in range(len(a)-1):
				app1_id,e1 = a[i][0].split(',')
				app2_id,e2 = a[i+1][0].split(',')
				#if app1_id != app2_id:
				device_app = self.INPUTS[str(app1_id)][0]['device']
				### update of the direct conflict dict with the indirect one because indirect conflict resolve the same direct conflict when direct ansd indirect conflcit occur on the same device.
				self.D.update({device_app:random.choice([a for a in self.eca_states_def[device_app] if a != e1])})
			
			if b:
				self.total_indirect_conflicts -= indirects
		
		### update current_states
		for _,values in self.app.items():
			self.current_states[values['device']] = self.state_event_map[values['device']][values['event']]

		self.holdIn('SEND',0)
			
	def outputFnc(self):
		''' DEVS output function.
		'''
		a = round(100*len(self.total_direct_conflicts)/self.nb_total_direct_conflicts,2)
		b = round(100*len(self.total_indirect_conflicts)/self.nb_total_indirect_conflicts,2)

		self.poke(self.OPorts[0], Message([a], self.timeNext))
		self.poke(self.OPorts[1], Message([b], self.timeNext))

		for d,i in self.out.items():
			if d in self.D:
				e = self.D[d]
				self.debugger(f"Resolving (direct/indirect) conflicts of {[str(j)+'/'+self.app[j]['event'] for j in self.app if self.app[j]['device']==d]} apps with the app {i+1} for {d}: {e} is sended to {d}")
			elif i+1 in self.app:
				e = self.app[i+1]['event']
				self.debugger(f"No direct conflict: {e} is sended to {d} by the {i+1} app")
			else:
				e = None
				self.debugger(f"Error: device {d}, app {i+1}")

			if e and len(self.OPorts)>2:
				self.poke(self.OPorts[i+2], Message([e], self.timeNext))
		
		return {}
		#for i in self.out:
		#	try:
		#		self.poke(self.OPorts[i-1], Message([self.out[i]], self.timeNext))
		#	except:
#				self.debugger('Need more outputs...')
		
	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.passivateIn('IDLE')

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
