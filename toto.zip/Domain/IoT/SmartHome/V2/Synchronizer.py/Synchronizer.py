# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		Synchronizer.py
 Model description:     Collect all inputs event from apps
 Authors:       		Laurent
 Organization:  		SPE UMR CNRS 6134
 Current date & time:   2020-10-26 09:32:28.238525
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

import copy 

### Model class ----------------------------------------------------------------
class Synchronizer(DomainBehavior):
	''' DEVS Class for the model Synchronizer
	'''

	def __init__(self, t=2.0, only_diff = False):
		''' Constructor.

			@param t: step for one execution cycle. If 0.0, triggering is immediate
			@param only_diff: send only the event of app that change its value
		'''

		DomainBehavior.__init__(self)

		self.step = t if t > 0.0 else INFINITY
		self.only_diff = only_diff

		self.initPhase('IDLE',self.step)

		### dict with app name for key and event list for value
		self.buffer = {}
		self.old_buffer = {}

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''
		
		for i in range(len(self.IPorts)):
			msg = self.peek(self.IPorts[i], *args)
			if msg:
				v = self.getMsgValue(msg)
				if self.step == INFINITY:
					self.buffer.update({i:v})
				else:
					if i in self.buffer:
						self.buffer[i].append(v)
					else:
						self.buffer.update({i:[v]})

		### change state depending on the step param and the new sigma
		if self.step != INFINITY:
			sigma = self.getSigma() - self.elapsed
			if sigma > 0.0:
				self.holdIn('IDLE', sigma)
			else:
				self.holdIn('SEND', 0.0)
		else:
			self.holdIn('SEND',0.0)

	def outputFnc(self):
		''' DEVS output function.
		'''
		#if self.phaseIs('SEND'):
			
		if self.step == INFINITY:
			### if only_diff attribite is True
			if self.only_diff:
				### value dct is used to store the difference between old_buffer and buffer
				value = {}
				for k1,v1 in self.buffer.items():
					for k2,v2 in self.old_buffer.items():
						if k1==k2 and v1!=v2:
							value[k1]=v2
				### if value is not empty, we send output msg
				p = self.poke(self.OPorts[0], Message(value, self.timeNext)) if value != {} else None
				### update old_buffer and buffer
				self.old_buffer.update(self.buffer)
				self.buffer = {}
				if p: return p
			### else we send the updated buffer
			else:
				return self.poke(self.OPorts[0], Message(self.buffer, self.timeNext))
		else:
			D = {}
			if len(self.buffer)==len(self.IPorts):
				for k,v in self.buffer.items():
					if v:
						D[k] = v.pop() #if v and self.only_diff else None

				self.buffer = {}

			if D != {}:
				p = self.poke(self.OPorts[0], Message(D, self.timeNext))

				return p

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		if self.phaseIs('SEND'):
			self.holdIn('IDLE',self.step)
	
	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
