# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		Synchronizer2.py
 Model description:     Collect all inputs event from apps
 Authors:       		Laurent
 Organization:  		SPE UMR CNRS 6134
 Current date & time:   2020-10-26 09:32:28.238525
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

from collections import deque

import re

def replace(match):
	flow_app_nb = match.group(1)
	occurence_nb = match.group(2)
	signal = match.group(3)
	if str(signal) != 'null':
		return '(%s in self.buffer and self.buffer[%s].count("%s") == %d)'%(flow_app_nb, flow_app_nb, signal, int(occurence_nb)+1)
	else:
		return '(%s in self.buffer and len(self.buffer[%s])>0)'%(flow_app_nb,flow_app_nb)

def toPython(string:str)->str:
	""" translate the triggercondition to python code in order to trigger the output fct
		ex: "Input(1,0) != null || Input(2,0) != null && Input(3,0) != null" -> (1 in buffer and len(buffer[1]>0)) or (2 in buffer and len(buffer[2]>0)) and (3 in buffer and len(buffer[3]>0))
		or 'Input(1,0) != null && Input(2,0) == "STOP" && Input(3,0) == "START"' -> (1 in buffer and len(buffer[1]>0)) and (2 in buffer and buffer[2].count("STOP") == 1) and (3 in buffer and buffer[3].count("START") == 1)
	"""
	cond = re.sub('[Input\(]+([\d]+)[, ]([\d]+)[\)]+[ !=]+[\'\"]?([\w]+)[\'\"]?', replace, string)
	return cond.replace("&&", 'and').replace('||', 'or')

### Model class ----------------------------------------------------------------
class Synchronizer2(DomainBehavior):
	''' DEVS Class for the model Synchronizer2
	'''

	def __init__(self, queue_size=100, triggercond='Input(1,0) != null && Input(2,0) != null && Input(3,0) != null'):
		''' Constructor.

			@param triggercond: the condition to trigger the cycle
			@param queue_size: size of the event queue of app
		'''

		DomainBehavior.__init__(self)

		self.queue_size = queue_size
		self.triggercond = toPython(triggercond)

		### dict with app name for key and event list for value
		self.buffer = {}

		self.initPhase('IDLE', INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''
		
		### fullfill the buffer with deque
		for i in range(len(self.IPorts)):
			msg = self.peek(self.IPorts[i], *args)
			if msg:
				v = self.getMsgValue(msg)
				### fisrt one
				if i+1 not in self.buffer:
					self.buffer.update({i+1:deque([v[0]],maxlen=self.queue_size)})
				else:
					self.buffer[i+1].append(v[0])
							
		if eval(self.triggercond):
			self.holdIn('SEND',0)
		else:
			self.passivate()

		return self.getState()

	def outputFnc(self):
		''' DEVS output function.
		'''
		### occurence selection process
		output = {}
		for i,elem in enumerate(getAppInfo(self.triggercond)):
			output[i] = self.buffer[i+1][int(elem[-1])]

		b = sorted(output.items(), key = lambda kv:(kv[0], kv[1]))
		p = self.poke(self.OPorts[0], Message(b, self.timeNext))
		self.buffer = {}
		return p
		
	def intTransition(self):
		''' DEVS internal transition function.
		'''
		if self.phaseIs('SEND'):
			self.holdIn('IDLE', INFINITY)

		return self.getState()
	
	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
