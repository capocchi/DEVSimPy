def getPythonConflictCond(string:str)->dict:
	"""
	"""
	# TODO
	return '{1: ("STOP","CLEAN","RESUME","PAUSE"), 2:("MUTE","UNMUTE"), 3:("MUTE","UNMUTE")}'

def getPythonStates(string:str)->dict:
	### TODO
	return '{1:("Cleaning","Stopped","Resumed","Paused"), 2:("Muted","Unmuted"), 3:("Muted","Unmuted")}'

def isDirectConflict(input_events,inputs,ts):
	### direct
	if len(input_events)<2:
		return None

	conflicts = []
	for k1 in input_events:
		for k2 in [k for k in input_events if k!=k1]:
			device1,event1,time1=k1[-1]['device'],k1[-1]['event'],k1[-1]['time']
			device2,event2,time2=k2[-1]['device'],k2[-1]['event'],k2[-1]['time']
			app1 = k1[0]
			app2 = k2[0]
			### direct conflcit when events off different app dedicated for same device!
			if (event1 != event2) and (abs(time2-time1) <= ts) and (inputs[app1] == inputs[app2]) and (device1 == device2):
				v = ('direct',sorted([str(app1)+'/'+event1+'/'+str(time1),str(app2)+'/'+event2+'/'+str(time2)]),device1)
				if v not in conflicts:
					conflicts.append(v)
	
	return conflicts or None 

def isIndirectConflict(input_events,features,current_states):
	### indirect

	conflicts = []				
	for f,v in features.items():
		states,events = eval(v)
		for a in states:
			device_f,state_f = a.split(',')

			for app,event in input_events:
				device_e,e,t = event['device'],event['event'],event['time']
				
				### indirect conflict appears when 
				### 1. device of feature and device targeted by the event are different
				### 2. the event sended by the app is in the evenet feature list
				### 3. the device in the features must by in the states feature.
				if device_f != device_e and e in events and '%s,%s'%(device_f,current_states[device_f]) in states:
					v = ('indirect',sorted(["%d/%s"%(app,e)]),(device_f,current_states[device_f]))
					if v not in conflicts:
						conflicts.append(v)

	return conflicts or None

def getConflictList(inputs,features,current_states,ts):
	""" Return the list of direct and indirect conflicts as generator.
	"""

	conflicts = set()


	### direct conflicts
	for app1,l1 in inputs.items():
		for app2,l2 in inputs.items():
			### different app but same events set and target device
			if app1!=app2: #and inputs[app1] == inputs[app2]:
				for v1 in l1:
					for v2 in l2:
						device1,event1,time1=v1['device'],v1['event'],v1['time']
						device2,event2,time2=v2['device'],v2['event'],v2['time']

						#print(device1,device2,event1,event2)
						### direct conflict when events of different app dedicated for same device!
						if (event1 != event2) and (abs(time2-time1) <= ts) and (device1 == device2):
							v = ('direct',tuple(sorted(["{app}/{event}/{time}".format(app=app1,event=event1,time=time1),"{app}/{event}/{time}".format(app=app2,event=event2,time=time2)])),device1)
							conflicts.add(v)

	### indirect conflicts
	for f,v in features.items():
		states,events = v
		for a in states:
			device_f,state_f = a.split(',')

			for app,event_list in inputs.items():
				for event in event_list:

					device_e,e,t = event['device'],event['event'],event['time']
			
					### indirect conflict appears when 
					### 1. device of feature and device targeted by the event are different
					### 2. the event sended by the app is in the event feature list
					### 3. the device in the features must by in the states feature.
					current_state_device_f = current_states[device_f]
					evt = "{},{}".format(app,e)

					if device_f != device_e and evt in events and "{},{}".format(device_f,current_state_device_f) in states:
						v = ('indirect',tuple(sorted([evt])),(device_f,current_state_device_f))
						conflicts.add(v)

	return conflicts

### Main program
if __name__ == '__main__':
	import random 
	import pprint

	# ### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	# INPUTS = {	"App_Robot":({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
	# 			"App_Phone_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
	# 			"App_RemoteControl_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
	# 		}

	# ### feature is used to indirect conflict detection
	# ### NOISE is the feature that is influenced by only the TV and the Robot device when they are in the state Unmuted and Cleaning
	# ### the indirect conflict appear only when the App_RemoteControl TV send U NMUTE or App_Roboot send CLEAN or APP_Phone_TV send MUTE.
	# FEATURES = {"NOISE":[('TV,Unmuted','Robot,Cleaning'),('App_RemoteControl_TV,UNMUTE', 'App_Robot,CLEAN', 'App_Phone_TV,MUTE')]}

	# ### STATES is the dict which is uded to make a relation between the device and its possible states
	# STATES = {"Robot":("Cleaning","Stopped","Resumed","Paused"), "Phone":("Muted","Unmuted"), "TV":("Muted","Unmuted")}

	### REMEDIOT

	MODES = ('user_away_mode','vacation_mode','sunrise_mode','sunset_mode','weather_value_update')

	DEVICES = ('text',
				'camera',
				'motion',
				'door',
				'windows',
				'ac',
				'heater',
				'lights',
				'electric_devices',
				'multi_sensor_switch',
				'speaker',
				'alarm',
				'high_power',
				'low_power.state',
				'fan',
				'fireplace',
				'curtain',
				'valve',
				'coffee',
				'outlet',
				'notification',
				'tap',
				'water_leakage',
				'tv',
				'music',
				'flashlight',
				'sprinkler',
				'air_dryer'
				)

	### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	INPUTS = {	"App_1":({"device":"wfh","event":"ON","time":0.0},{"device":"text","event":"OFF","time":0.0}),
				"App_2":({"device":"user_away_mode","event":"ON","time":0.0},{"device":"motion","event":"ON","time":0.0},
						{"device":"door","event":"OFF","time":0.0},{"device":"windows","event":"OFF","time":0.0}),
				"App_3":({"device":"windows","event":"ON","time":0.0},),
				"App_4":({"device":"text","event":"ON","time":0.0},),
			}

	# # ### STATES is the dict which is uded to make a relation between the device and its possible states
	STATES = {}
	for d in DEVICES:
		STATES[d] = ("ON","OFF")

	FEATURES = {}
	# ### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	# INPUTS = {	"App_AC":({"device":"AC","event":"COOL","time":0.0},{"device":"AC","event":"HEAT","time":0.0},{"device":"AC","event":"OFF","time":0.0}), 
	# 			"App_Light":({"device":"Light","event":"ON","time":0.0},{"device":"Light","event":"OFF","time":0.0},{"device":"Light","event":"FLASH","time":0.0}), 
	# 			"App_Window":({"device":"Window","event":"OPEN","time":0.0},{"device":"Window","event":"CLOSE","time":0.0}),
	# 			"App_Fan":({"device":"Fan","event":"ON","time":0.0},{"device":"Fan","event":"OFF","time":0.0}),
	# 			"App_Heater":({"device":"Heater","event":"ON","time":0.0},{"device":"Heater","event":"OFF","time":0.0}),
	# 			"App_FirePlace":({"device":"FirePlace","event":"ON","time":0.0},{"device":"FirePlace","event":"OFF","time":0.0}),
	# 			"App_MainDoor":({"device":"Door","event":"OPEN","time":0.0},{"device":"Door","event":"CLOSE","time":0.0}),
	# 			"App_Curtain":({"device":"Curtain","event":"OPEN","time":0.0},{"device":"Curtain","event":"CLOSE","time":0.0}),
	# 			"App_Humidifier":({"device":"Humidifier","event":"ON","time":0.0},{"device":"Humidifier","event":"OFF","time":0.0}),
	# 			"App_Speaker":({"device":"Speaker","event":"SEND_WARNING","time":0.0},),
	# 			"App_TV":({"device":"TV","event":"ON","time":0.0},{"device":"TV","event":"OFF","time":0.0})
	# 		}

	# # ### STATES is the dict which is uded to make a relation between the device and its possible states
	# STATES = {	"AC":("HEATING","COOLING","OFF"), 
	# 			"Light":("LIGHT_ON","LIGHT_OFF","FLASH_LIGHT"), 
	# 			"Window":("OPENING","CLOSING","CLOSED","OPENED"),
	# 			"Fan":("FAN_ON","FAN_OFF"), 
	# 			"Heater":("HEATER_ON","HEATER_OFF"), 
	# 			"FirePlace":("FIREPLACE_ON","FIREPLACE_OFF"), 
	# 			"MainDoor":("OPENING","CLOSING","CLOSED","OPENED"),
	# 			"Curtain":("OPENING","CLOSING","CLOSED","OPENED"),
	# 			"Humidifier":("HUMIDIFIER_ON","HUMIDIFIER_OFF"), 
	# 			"Speaker":("WAIT","SEND"),
	# 			"TV":("TV_OFF","TV_ON")
	# 			}



	# FEATURES = {"TEMPERATURE":[('Window,OPENED','AC,HEATING','AC,COOLING','Fan,FAN_ON','Heater,HEATER_ON','FirePlace,FIREPLACE_ON'),
	# 					('App_AC,HEAT', 'App_AC,COOL', 'App_Window,OPEN', 'App_Fan,ON', 'App_Heater,ON','App_FirePlace,ON')],
	# 			"VENTILATION": [('Window,OPENED','Fan,FAN_ON','MainDoor,OPENED'),
	# 					('App_Window,OPEN', 'App_Fan,ON','App_MainDoor,OPEN')],
	# 			"ILLUMINATION": [('Curtain,OPENED','Curtain,CLOSED','Light,LIGHT_ON','Light,LIGHT_OFF'),
	# 					('App_Curtain,OPEN','App_Curtain,CLOSE','App_Light,ON','App_Light,OFF')],
	# 			"HUMIDITY": [('Fan,FAN_OFF','Fan,FAN_ON','Humidifier,HUMIDIFIER_ON','Humidifier,HUMIDIFIER_OFF'),
	# 					('App_Fan,ON','App_Fan,OFF','App_Humidifier,ON','App_Humidifier,OFF')],
	# 			"ENERGY": [('TV,TV_OFF','AC,','Humidifier,HUMIDIFIER_ON','Humidifier,HUMIDIFIER_OFF'),
	# 					('App_Fan,ON','App_Fan,OFF','App_Humidifier,ON','App_Humidifier,OFF')],
	# 			}

	### size of the loop used to initialize the state of the devices 
	N = 100

	### list of possible direct and indirect conflicts
	conflicts = set()

	### try with several inital states generated randomly
	for i in range(N):
		current_states = dict((app,random.choice(states)) for app,states in STATES.items())
		conflicts.update(getConflictList(INPUTS,FEATURES,current_states,0.0))	
		
	pprint.pprint(conflicts)