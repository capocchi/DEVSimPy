# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          <filename.py>
 Model:         <describe model>
 Authors:       <your name>
 Organization:  <your organization>
 Date:          <yyyy-mm-dd>
 License:       <your license>
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

def Strategy1(D):
	if ("MotionGen" in D) and ("LightGen" in D):
		### the last LightGen value
		if D['LightGen'] > 50:
			if D['MotionGen'] > 1 and D['MotionGen'] < 5:
				return 'OFF'
			else:
				return 'OFF'
		else:
			if D['MotionGen'] > 1 and D['MotionGen'] < 5:
				return 'ON'
			else:
				return 'OFF'

def Strategy4(D, previous_state):
### no preemption with strategy 4
	if ("SwitchGen" in D) and ("LightGen" in D):
		### the last LightGen value
		if D['LightGen'] > 50:
			return 'OFF'
		else:
			if previous_state == 'ON':
				return 'ON'

def Strategy2(lightGen, L_MotionGen, previous_state, power):

	### decrease
	if L_MotionGen[0].value[1] < L_MotionGen[-1].value[1]:
		#self.debugger("MotionGen dim")

		if lightGen > 50:
			state = 'OFF'
		else:
			if previous_state == 'ON':
				state = 'OFF'
				power -= (L_MotionGen[-1].value[1] - L_MotionGen[0].value[1])*20
			else:
				state = 'OFF'
	else:
		#self.debugger("MotionGen aug")
		if lightGen > 50:
			state = 'OFF'
		else:
			if previous_state == 'ON':
				state = 'OFF'
				power += (L_MotionGen[-1].value[1] - L_MotionGen[0].value[1])*20
			else:
				state = 'ON'
				power += (L_MotionGen[-1].value[1] - L_MotionGen[0].value[1])*20

	return (state,power)

### Model class ----------------------------------------------------------------
class Lamp(DomainBehavior):
	''' DEVS Class for Lamp model
		with strategies
	'''

	def __init__(self, s=("S1", "S2", "S4"), p=0, ss=0, so=1):
		''' Constructor.

			@param s = strategy
			@param p = power
			@param ss = sigma selection
			@param so = sigma observation
		'''
		DomainBehavior.__init__(self)

		### local copy
		self.s = s[0]
		self.power = p
		self.sigma_sel = ss
		self.sigma_obs = so

		### list of the port corresponding to the preemptif model
		self.PrePortList = []
		### buffer of messages
		self.buffer = []
		### preemptif value
		self.pre_value = None
		### previous state
		self.previous_state = 'OFF'

		self.state = {	'status': 'OFF', 'sigma':INFINITY}

	def extTransition(self):
		''' DEVS external transition function.
		'''
		
		for i in range(len(self.IPorts)):
			msg = self.peek(self.IPorts[i])
		
			if msg:
				### preemptif
				if i in self.PrePortList:
					if self.state['status'] in ('OFF', 'ON'):
						self.state['status'] = 'PRE'
						self.state['sigma'] = 0
						self.pre_value = msg.value[1]
				### non preemptif
				else:
					self.buffer.append(msg)
					if self.state['status'] in ('OFF', 'ON'):
						self.state['status'] = 'OBS'
						self.state['sigma'] = self.sigma_obs
					elif self.state['status'] == 'OBS':
						self.state['sigma'] -= self.elapsed
					else:
						pass

		self.debugger(self.state)

	def outputFnc(self):
		''' DEVS output function.
		'''
		pass

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		if self.state['status'] in ('PRE','OBS'):
			self.state['status'] = 'SEL'
			self.state['sigma'] = self.sigma_sel
		elif self.state['status'] == 'SEL':
			### preemption
			if self.PrePortList != []:
				self.state['status'] = 'ON' if self.pre_value == 'on' else 'OFF'
			else:
				if self.s == "S4":
					### dico of message type and value
					D = dict(map(lambda a: (a.value[0],a.value[1]), self.buffer))
					
					self.state['status'] = Strategy4(D, self.previous_state)

				elif self.s == "S1":
					### dico of message type and value
					D = dict(map(lambda a: (a.value[0],a.value[1]), self.buffer))
					
					self.state['status'] = Strategy1(D)

					self.debugger("lighGen %s"%str(D['LightGen']))
					self.debugger("motionGen %s"%str(D['MotionGen']))
				### S2
				else:
					### last LightGen
					lightGen = filter(lambda a: a.value[0] == "LightGen", self.buffer)[-1].value[1]
					### all MotionGen
					L_MotionGen = filter(lambda a: a.value[0] == "MotionGen", self.buffer)
					
					self.state['status'], self.power = Strategy2(lightGen, L_MotionGen, self.previous_state, self.power)

					self.debugger("lighGen %s"%str(lightGen))
					
			self.previous_state = self.state['status']
			self.state['sigma'] = INFINITY
		else:
			pass

		self.debugger(self.state)

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.state['sigma']
