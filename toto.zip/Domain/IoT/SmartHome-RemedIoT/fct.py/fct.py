def getPythonConflictCond(string:str)->dict:
	"""
	"""
	# TODO
	return '{1: ("STOP","CLEAN","RESUME","PAUSE"), 2:("MUTE","UNMUTE"), 3:("MUTE","UNMUTE")}'

def getPythonStates(string:str)->dict:
	### TODO
	return '{1:("Cleaning","Stopped","Resumed","Paused"), 2:("Muted","Unmuted"), 3:("Muted","Unmuted")}'

def isDirectConflict(input_events,inputs,ts):
	### direct
	if len(input_events)<2:
		return None

	conflicts = set()
	for k1 in input_events:
		for k2 in [k for k in input_events if k!=k1]:
			device1,event1,time1=k1[-1]['device'],k1[-1]['event'],k1[-1]['time']
			device2,event2,time2=k2[-1]['device'],k2[-1]['event'],k2[-1]['time']
			app1 = k1[0]
			app2 = k2[0]
			### direct conflcit when events off different app dedicated for same device!
			if (event1 != event2) and (abs(time2-time1) <= ts) and (device1 == device2):
				v = ('direct',tuple(sorted(["{app}/{event}/{time}".format(app=app1,event=event1,time=time1),"{app}/{event}/{time}".format(app=app2,event=event2,time=time2)])),device1)
				#v = ('direct',sorted([str(app1)+'/'+event1+'/'+str(time1),str(app2)+'/'+event2+'/'+str(time2)]),device1)
				#if v not in conflicts:
				conflicts.add(v)
	
	return conflicts or None 

def isIndirectConflict(input_events,features,current_states):
	### indirect

	conflicts = set()	
	for f,v in features.items():
		states,events = eval(v)
		for a in states:
			device_f,state_f = a.split(',')

			for app,event in input_events:
				device_e,e,t = event['device'],event['event'],event['time']
				
				### indirect conflict appears when 
				### 1. device of feature and device targeted by the event are different
				### 2. the event sended by the app is in the evenet feature list
				### 3. the device in the features must by in the states feature.
				if device_f != device_e and e in events and '%s,%s'%(device_f,current_states[device_f]) in states:
					v = ('indirect',tuple(sorted([e])),(device_f,current_states[device_f]),f)
					#v = ('indirect',sorted(["%d/%s"%(app,e)]),(device_f,current_states[device_f]))
					#if v not in conflicts:
					conflicts.add(v)

	return conflicts or None

def getConflictList(inputs,features,current_states,ts):
	""" Return the list of direct and indirect conflicts as generator.
	"""

	conflicts = set()

	### direct conflicts
	for app1,l1 in inputs.items():
		for app2,l2 in inputs.items():
			### different app but same events set and target device
			if app1!=app2:
				for v1 in l1:
					for v2 in l2:
						device1,event1,time1=v1['device'],v1['event'],v1['time']
						device2,event2,time2=v2['device'],v2['event'],v2['time']

						### direct conflict when events of different app dedicated for same device!
						if (event1 != event2) and (abs(time2-time1) <= ts) and (device1 == device2):
							v = ('direct',tuple(sorted(["{app}/{event}/{time}".format(app=app1,event=event1,time=time1),"{app}/{event}/{time}".format(app=app2,event=event2,time=time2)])),device1)
							conflicts.add(v)

	### indirect conflicts
	for feature,elem in features.items():
		print(elem)
		for e in elem:
			states,events = e
			for a in states:
				device_f,state_f = a.split(',')

				for app,event_list in inputs.items():
					for event in event_list:

						device_e,e,t = event['device'],event['event'],event['time']
				
						### indirect conflict appears when 
						### 1. device of feature and device targeted by the event are different
						### 2. the event sended by the app is in the event feature list
						### 3. the device in the features must by in the states feature.
						current_state_device_f = current_states[device_f]
						evt = "{},{}".format(app,e)

						if device_f != device_e and evt in events and "{},{}".format(device_f,current_state_device_f) in states:
							v = ('indirect',tuple(sorted([evt])),(device_f,current_state_device_f),feature)
							conflicts.add(v)

	return conflicts

### Main program
if __name__ == '__main__':
	import random 
	import pprint

	# ### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	# INPUTS = {	"App_Robot":({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
	# 			"App_Phone_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
	# 			"App_RemoteControl_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
	# 		}

	# ### feature is used to indirect conflict detection
	# ### NOISE is the feature that is influenced by only the TV and the Robot device when they are in the state Unmuted and Cleaning
	# ### the indirect conflict appear only when the App_RemoteControl TV send UNMUTE or App_Roboot send CLEAN or APP_Phone_TV send MUTE.
	# FEATURES = {"NOISE":[('TV,Unmuted','Robot,Cleaning'),('App_RemoteControl_TV,UNMUTE', 'App_Robot,CLEAN', 'App_Phone_TV,MUTE')]}

	# ### STATES is the dict which is uded to make a relation between the device and its possible states
	# STATES = {"Robot":("Cleaning","Stopped","Resumed","Paused"), "Phone":("Muted","Unmuted"), "TV":("Muted","Unmuted")}

	### REMEDIOT

	i = 0
	INPUTS = {}
	ACTUATORS_STATES = {}

	### right part of rules.txt
	ACTUATORS = set()

	### left part of rules.txt
	SENSORS = set()

	### rules.txt analysis
	with open('rules.txt','r') as f:
		### for each line
		for l in f.readlines():
			### for each app
			if '#' in l:
				#INPUTS["App_{}".format(i)] = []
				i+=1
			else:
				### split with then and and to find the list of actuators
				a_list = l.split('then')[-1].split('and')

				### split with then and and to find the list of sensors
				s_list = l.split('then')[0].replace('if ','').split('and')
				
				### for each string containing sensors state
				for s in s_list:
					### actuators
					SENSORS.add(s.split('.')[0].strip())

				### for each string containing actuators state 
				for s in a_list:
					### actuators
					a = s.split('.')[0].strip()
					ACTUATORS.add(a)

					### ON = 1 / OFF = 0
					boolean = s.split('=')[-1].strip()
					elem = {"device":f"{a}","event":"ON","time":0.0} if boolean == "1" else {"device":f"{a}","event":"OFF","time":0.0}
					
					INPUTS[f"App_{i-1}_{a}"] = [elem]

					#if elem not in INPUTS[f"App_{i-1}_{a}"]:# and b not in INPUTS["App_{}".format(i-1)]:
					#INPUTS[f"App_{i-1}_{a}"].append(elem)
						#INPUTS["App_{}".format(i-1)].append(b)
					ACTUATORS_STATES[a] = ("1","0")

	# ### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	# INPUTS = {	"App_1":({"device":"wfh","event":"ON","time":0.0},{"device":"text","event":"OFF","time":0.0}),
	# 			"App_2":({"device":"user_away_mode","event":"ON","time":0.0},{"device":"motion","event":"ON","time":0.0},
	# 					{"device":"door","event":"OFF","time":0.0},{"device":"windows","event":"OFF","time":0.0}),
	# 			"App_3":({"device":"windows","event":"ON","time":0.0},),
	# 			"App_4":({"device":"text","event":"ON","time":0.0},),
	# 			"App_5":({"device":"text","event":"ON","time":0.0},),
	# 			"App_6":({"device":"ac","event":"ON","time":0.0},{"device":"heater","event":"ON","time":0.0}),
	# 			"App_7":({"device":"lights","event":"ON","time":0.0},{"device":"lights","event":"OFF","time":0.0},{"device":"vacation_mode","event":"ON","time":0.0}),
	# 			"App_8":({"device":"door","event":"ON","time":0.0},),
	# 			"App_9":({"device":"text","event":"ON","time":0.0},),
	# 			"App_10":({"device":"lights","event":"ON","time":0.0},{"device":"lights","event":"OFF","time":0.0},{"device":"motion","event":"ON","time":0.0},{"device":"motion","event":"OFF","time":0.0})
	# 		}

	FEATURES = {
				'STATIONARITY': ('camera,0','motion,0'),
				'ABSENCE': ('user,0','camera,0','user_away_mode,0','wfh,0'),
				'COOL_WITH_HIGHT_EXTERNAL_TEMP': ('ac,1','windows,0','fan,1'),
				'COOL_WITH_LOW_EXTERNAL_TEMP': ('ac,1','windows,1','fan,1'),
				'HOT_WITH_HIGHT_EXTERNAL_TEMP': ('heater,1','windows,1','fireplace,1'),
				'HOT_WITH_LOW_EXTERNAL_TEMP': ('heater,1','windows,0','fireplace,1'),
				'VENTILATION': ('fan,1','windows,1','door,1'),
				'HUMIDITY': ('fan,0','valve,0'),
				'LUMINATION': ('light,1','lights,1','curtain,1'),
				'ENERGY': ('high_power,0','low_power,1'),
				'CONFORT': ('curtain,0', 'lights,0', 'speaker,0'),
				'SAFETY': ('windows,0', 'camera,1', 'door,0','alarm,1','electric_devices,0')
	}

	FEATURE_RULES = {}

	for f,devices in FEATURES.items():
		T = set()
		for elem in devices:
			d,s = elem.split(',')
			for app,l in INPUTS.items():
				for elem in l:
					if elem['device'] == d:
						if s =='0':
							T.add(f'{app},OFF')
						else:
							T.add(f'{app},ON')

		FEATURE_RULES[f] = [(FEATURES[f],T)]
	
	# FEATURE_RULES = {
	# 				'STATIONARITY': [(FEATURES['STATIONARITY'],('App_1,OFF','App_44,OFF','App_67,OFF','App_9,OFF'))],
	# 				'ABSENCE': [(FEATURES['ABSENCE'],('App_45,OFF','App_72,OFF','App_1,OFF','App_44,OFF','App_67,OFF','App_9,OFF','App_22,OFF')),],
	# 				'HOT': [(FEATURES['HOT'],('App_5,ON','App_24,ON','App_25,ON','App_26,ON','App_27,ON','App_40,ON','App_47,ON','App_51,ON','App_61,ON','App_67,ON','App_70,ON','App_1,OFF','App_2,OFF','App_21,OFF','App_22,OFF','App_53,OFF','App_33,ON','App_70,ON'))],
	# 				'COOL':[(FEATURES['COOL'],('App_5,ON','App_24,ON','App_25,ON','App_26,ON','App_51,ON','App_67,ON','App_1,OFF','App_2,OFF','App_21,OFF','App_22,OFF','App_53,OFF','App_28,ON','App_29,ON','App_30,ON','App_31,ON','App_32,ON','App_40,ON','App_46,ON','App_48,ON','App_59,ON','App_61,ON'))],
	# 				'VENTILATION': [(FEATURES['VENTILATION'],('App_28,ON','App_29,ON','App_30,ON','App_31,ON','App_32,ON','App_40,ON','App_46,ON','App_48,ON','App_59,ON','App_61,ON','App_1,ON','App_2,ON','App_21,ON','App_22,ON','App_53,ON','App_7,ON','App_34,ON','App_72,ON'))],
	# 				'HUMIDITY': [(FEATURES['HUMIDITY'],('App_29,OFF', 'App_52,OFF', 'App_28,OFF', 'App_40,OFF', 'App_48,OFF', 'App_54,OFF', 'App_59,OFF', 'App_61,OFF', 'App_50,OFF', 'App_32,OFF', 'App_46,OFF', 'App_49,OFF', 'App_31,OFF', 'App_30,OFF'))],
	# 				'LUMINATION': [(FEATURES['LUMINATION'],('App_15,ON', 'App_40,ON', 'App_39,ON', 'App_58,ON', 'App_16,ON', 'App_55,ON', 'App_68,ON'))],
	# 				'ENERGY': [(FEATURES['ENERGY'],('App_67,ON','App_25,OFF', 'App_53,OFF'))],
	# 				'CONFORT': [(FEATURES['CONFORT'],('App_68,OFF', 'App_58,OFF', 'App_16,OFF', 'App_64,OFF', 'App_39,OFF', 'App_40,OFF', 'App_17,OFF', 'App_20,OFF', 'App_66,OFF', 'App_15,OFF', 'App_54,OFF', 'App_65,OFF', 'App_63,OFF', 'App_18,OFF', 'App_59,OFF', 'App_72,OFF', 'App_55,OFF', 'App_14,OFF', 'App_62,OFF'))],
	# 				'SAFETY': [(FEATURES['SAFETY'],('App_22,OFF', 'App_44,ON', 'App_10,OFF', 'App_15,ON', 'App_21,OFF', 'App_46,OFF', 'App_53,OFF', 'App_54,ON', 'App_67,ON', 'App_34,OFF', 'App_12,OFF', 'App_2,OFF', 'App_1,ON', 'App_7,OFF', 'App_1,OFF', 'App_72,OFF', 'App_13,OFF'))]
	# }

	### pour les conflicts directes, résolution par ordre de priorité des applications.
	### pour les conflicts indirectes, résolution par ordre de priorité des devices.
	### dans remedIoT résiltion par ordre de priorité (utility, safety, energy...) dans le graph.

	### size of the loop used to initialize the state of the devices 
	N = 100

	### list of possible direct and indirect conflicts
	conflicts = set()

	### try with several inital states generated randomly
	for i in range(N):
		current_states = dict((app,random.choice(states)) for app,states in ACTUATORS_STATES.items())
		conflicts.update(getConflictList(INPUTS,FEATURE_RULES,current_states,0.0))	
	
	# print("Actuators (right): ",ACTUATORS)
	# print("Sensors (left):",SENSORS)
	# print(ACTUATORS-SENSORS)

	### number of app
	print("Number of apps {}".format(len(INPUTS)))

	### number of direct conflicts
	print("Number of direct conflicts {}".format(len([c for c in conflicts if 'direct' == c[0]])))

	### number of indirect conflicts
	print("Number of indirect conflicts {}".format(len([c for c in conflicts if 'indirect' == c[0]])))

	### 1052 direct conflicts
	### 316 if boolean from rules.txt
	#pprint.pprint(len(conflicts))

	#t = ""
	#for i in range(1,137):
	#	t+= f"Input({i})=('ON','OFF') "
	#print(t)

	#t = {}
	#for a in list(SENSORS)+list(ACTUATORS):
	#	t[f"{a}"]=('1','0') 

	#print(t)