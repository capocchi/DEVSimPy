# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          Window.py
 Model:         Import scxml file from Window to create synchrone fsm.  
                If the clk param is >= 1000000.0, the external function is active.
                Otherwise, the internal transirion function is alone and the model sends output
                with clk frequency. The ta can be specified into Window by specifying the state as 'STATE:ta'.
                The input and output event are specified when the state defined into Window.
 Authors:       L. Capocchi
 Organization:  UMR CNRS 6134
 Date:          11.02.2020
 License:       GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

from FSM import FSM

import imp
import random
import os

### Model class ----------------------------------------------------------------
class Window(DomainBehavior):
	''' DEVS Class for Window model
	'''

	def __init__(self, filename="scxml.xml", clk=1000000.0):
		''' Constructor.

			@param filename: The file name of the fsm from Window software.
			@param clk: The clock of the internal transition function (if >= 1000000.0, external function is active)
		'''
		DomainBehavior.__init__(self)

		### local copy
		self.fn = filename
		self.clk = clk

		self.fsm = None

		### if the file exist
		if os.path.isfile(self.fn):
			### the code of the module can be changed by the user before simulation
			imp.reload(FSM)
			### FSM instanciation and SCXML file loading
			self.fsm = FSM.FSM()
			self.fsm.initFromSCXML(self.fn)
			self.out = self.fsm.getCurrentOutput()
			self.initPhase(self.fsm.getInitState(),self.clk)
		else:
			self.initPhase('IDLE',self.clk)

	def extTransition(self):
		''' DEVS external transition function.
		'''

		### peek the unique port
		msg = self.peek(self.IPorts[0])
		evt = msg.value[0]

		### change the state depending on the received event only if event is acceptable by the fsm
		if self.fsm:
			if self.fsm.isInEvents(evt):
				### the next methode return the next state and the output (possible None)
				status, self.out = self.fsm.next(evt)
				if ':' in status:
					s,ta = status.split(':')
				else:
					s = status
					ta = 0
				self.holdIn(s,float(ta))
			else:
				### event is not reconized by the fsm
				self.passivateIn('IDLE')
				print("event %s not reconized!"%evt)
		else:
			self.passivateIn('IDLE')
			print('scxml is not specyfied!')

	def outputFnc(self):
		''' DEVS output function.
		'''
		if not self.phaseIs('IDLE'):
			if isinstance(self.out,list):
				for i,out in enumerate(self.out):
					self.poke(self.OPorts[i], Message([out,0,0], self.timeNext))
			else:
				### send the output of the fsm 
				self.poke(self.OPorts[0], Message([self.out,0,0], self.timeNext))
		
	def intTransition(self):
		''' DEVS internal transition function.
		'''
		
		if self.clk < 1000000:
			status, out = self.fsm.next(random.choice(self.fsm.getEvents()))
			self.out = self.fsm.getCurrentOutput()
		else:
			status = self.fsm.getCurrentState()

		if ':' in status:
			s,ta = status.split(':')
			self.holdIn(s,float(ta))
		else:
			self.holdIn(status,self.clk)
		
	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
