# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		AddDeviceName.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2021-04-12 14:18:22.170518
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class AddDeviceName(DomainBehavior):
	''' DEVS Class for the model AddDeviceName
	'''

	def __init__(self, device_names=['App_0_wfh', 'App_0_text', 'App_1_user_away_mode', 'App_1_motion', 'App_1_camera', 'App_1_door', 'App_1_windows', 'App_2_windows', 'App_3_text', 'App_4_text', 'App_5_ac', 'App_5_heater', 'App_6_vacation_mode', 'App_6_light', 'App_7_door', 'App_8_text', 'App_9_light', 'App_9_motion', 'App_10_light', 'App_10_electric_devices', 'App_11_multi_sensor_switch', 'App_12_user_away_mode', 'App_12_text', 'App_12_electric_devices', 'App_13_electric_devices', 'App_14_speaker', 'App_15_sunrise_mode', 'App_15_alarm', 'App_15_sunset_mode', 'App_15_lights', 'App_16_text', 'App_16_lights', 'App_17_speaker', 'App_18_speaker', 'App_19_weather_value_update', 'App_20_speaker', 'App_20_text', 'App_21_windows', 'App_22_windows', 'App_23_light', 'App_24_heater', 'App_24_ac', 'App_25_high_power', 'App_25_ac', 'App_25_heater', 'App_26_ac', 'App_26_heater', 'App_27_heater', 'App_28_fan', 'App_29_fan', 'App_30_fan', 'App_31_fan', 'App_32_fan', 'App_33_fireplace', 'App_34_door', 'App_35_light', 'App_36_light', 'App_37_light', 'App_38_light', 'App_39_curtain', 'App_40_curtain', 'App_40_light', 'App_40_fan', 'App_40_heater', 'App_41_light', 'App_42_light', 'App_43_light', 'App_44_camera', 'App_45_user', 'App_46_fan', 'App_46_door', 'App_47_light', 'App_47_heater', 'App_48_fan', 'App_48_text', 'App_49_text', 'App_49_valve', 'App_49_coffee', 'App_49_outlet', 'App_50_notification', 'App_50_light', 'App_50_valve', 'App_51_notification', 'App_51_heater', 'App_51_ac', 'App_52_mode_change', 'App_52_light', 'App_52_valve', 'App_52_text', 'App_53_windows', 'App_53_high_power', 'App_54_camera', 'App_54_speaker', 'App_54_valve', 'App_55_lights', 'App_56_tap', 'App_57_tap', 'App_57_water_leakage', 'App_58_tv', 'App_58_speaker', 'App_58_curtain', 'App_58_light', 'App_59_music', 'App_59_speaker', 'App_59_fan', 'App_60_air_dryer', 'App_61_fan', 'App_61_valve', 'App_61_light', 'App_61_heater', 'App_61_tap', 'App_62_speaker', 'App_62_text', 'App_63_speaker', 'App_63_flashlight', 'App_64_speaker', 'App_65_text', 'App_65_speaker', 'App_66_text', 'App_66_speaker', 'App_67_low_power', 'App_67_ac', 'App_67_heater', 'App_67_light', 'App_67_camera', 'App_68_window', 'App_68_curtain', 'App_69_sprinkler', 'App_70_heater', 'App_70_fireplace', 'App_70_text', 'App_71_text', 'App_72_door', 'App_72_user', 'App_72_speaker', 'App_73_light']):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.device_names = device_names
		
		self.outputs = {}

		self.initPhase('IDLE',INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''

		for i in range(len(self.IPorts)):
			p = self.IPorts[i]
			msg = self.peek(p, *args)
			if msg:
				self.outputs[i] = (self.device_names[i].split('_')[-1],self.getMsgValue(msg))

		self.holdIn('SEND',0)

		return self.getState()

	def outputFnc(self):
		''' DEVS output function.
		'''
		for i,v in self.outputs.items():
			print(f"{v[0]},{v[1][0]}")
			self.poke(self.OPorts[i], Message([f"{v[0]},{v[1][0]}",0,0], self.timeNext))
		return {}

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.outputs = {}

		self.passivate()
		return self.getState()

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
