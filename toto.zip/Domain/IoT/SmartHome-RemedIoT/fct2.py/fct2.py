from functools import cache

def getPythonConflictCond(string:str)->dict:
	"""
	"""
	# TODO
	#return {1: ('ON', 'OFF'), 2: ('ON', 'OFF'), 3: ('ON', 'OFF'), 4: ('ON', 'OFF'), 5: ('ON', 'OFF'), 6: ('ON', 'OFF'), 7: ('ON', 'OFF'), 8: ('ON', 'OFF'), 9: ('ON', 'OFF'), 10: ('ON', 'OFF'), 11: ('ON', 'OFF'), 12: ('ON', 'OFF'), 13: ('ON', 'OFF'), 14: ('ON', 'OFF'), 15: ('ON', 'OFF'), 16: ('ON', 'OFF'), 17: ('ON', 'OFF'), 18: ('ON', 'OFF'), 19: ('ON', 'OFF'), 20: ('ON', 'OFF'), 21: ('ON', 'OFF'), 22: ('ON', 'OFF'), 23: ('ON', 'OFF'), 24: ('ON', 'OFF'), 25: ('ON', 'OFF'), 26: ('ON', 'OFF'), 27: ('ON', 'OFF'), 28: ('ON', 'OFF'), 29: ('ON', 'OFF'), 30: ('ON', 'OFF'), 31: ('ON', 'OFF'), 32: ('ON', 'OFF'), 33: ('ON', 'OFF'), 34: ('ON', 'OFF'), 35: ('ON', 'OFF'), 36: ('ON', 'OFF'), 37: ('ON', 'OFF'), 38: ('ON', 'OFF'), 39: ('ON', 'OFF'), 40: ('ON', 'OFF'), 41: ('ON', 'OFF'), 42: ('ON', 'OFF'), 43: ('ON', 'OFF'), 44: ('ON', 'OFF'), 45: ('ON', 'OFF'), 46: ('ON', 'OFF'), 47: ('ON', 'OFF'), 48: ('ON', 'OFF'), 49: ('ON', 'OFF'), 50: ('ON', 'OFF'), 51: ('ON', 'OFF'), 52: ('ON', 'OFF'), 53: ('ON', 'OFF'), 54: ('ON', 'OFF'), 55: ('ON', 'OFF'), 56: ('ON', 'OFF'), 57: ('ON', 'OFF'), 58: ('ON', 'OFF'), 59: ('ON', 'OFF'), 60: ('ON', 'OFF'), 61: ('ON', 'OFF'), 62: ('ON', 'OFF'), 63: ('ON', 'OFF'), 64: ('ON', 'OFF'), 65: ('ON', 'OFF'), 66: ('ON', 'OFF'), 67: ('ON', 'OFF'), 68: ('ON', 'OFF'), 69: ('ON', 'OFF'), 70: ('ON', 'OFF'), 71: ('ON', 'OFF'), 72: ('ON', 'OFF'), 73: ('ON', 'OFF'), 74: ('ON', 'OFF'), 75: ('ON', 'OFF'), 76: ('ON', 'OFF'), 77: ('ON', 'OFF'), 78: ('ON', 'OFF'), 79: ('ON', 'OFF'), 80: ('ON', 'OFF'), 81: ('ON', 'OFF'), 82: ('ON', 'OFF'), 83: ('ON', 'OFF'), 84: ('ON', 'OFF'), 85: ('ON', 'OFF'), 86: ('ON', 'OFF'), 87: ('ON', 'OFF'), 88: ('ON', 'OFF'), 89: ('ON', 'OFF'), 90: ('ON', 'OFF'), 91: ('ON', 'OFF'), 92: ('ON', 'OFF'), 93: ('ON', 'OFF'), 94: ('ON', 'OFF'), 95: ('ON', 'OFF'), 96: ('ON', 'OFF'), 97: ('ON', 'OFF'), 98: ('ON', 'OFF'), 99: ('ON', 'OFF'), 100: ('ON', 'OFF'), 101: ('ON', 'OFF'), 102: ('ON', 'OFF'), 103: ('ON', 'OFF'), 104: ('ON', 'OFF'), 105: ('ON', 'OFF'), 106: ('ON', 'OFF'), 107: ('ON', 'OFF'), 108: ('ON', 'OFF'), 109: ('ON', 'OFF'), 110: ('ON', 'OFF'), 111: ('ON', 'OFF'), 112: ('ON', 'OFF'), 113: ('ON', 'OFF'), 114: ('ON', 'OFF'), 115: ('ON', 'OFF'), 116: ('ON', 'OFF'), 117: ('ON', 'OFF'), 118: ('ON', 'OFF'), 119: ('ON', 'OFF'), 120: ('ON', 'OFF'), 121: ('ON', 'OFF'), 122: ('ON', 'OFF'), 123: ('ON', 'OFF'), 124: ('ON', 'OFF'), 125: ('ON', 'OFF'), 126: ('ON', 'OFF'), 127: ('ON', 'OFF'), 128: ('ON', 'OFF'), 129: ('ON', 'OFF'), 130: ('ON', 'OFF'), 131: ('ON', 'OFF'), 132: ('ON', 'OFF'), 133: ('ON', 'OFF'), 134: ('ON', 'OFF'), 135: ('ON', 'OFF'), 136: ('ON', 'OFF')}
	return {1:("Stopped","Cleaning","Resumed","Paused"), 3:("Muted", "Unmuted")}
	
def getPythonStates(string:str)->dict:
	### TODO
	return '{1:("Cleaning","Stopped","Resumed","Paused"), 2:("Muted","Unmuted"), 3:("Muted","Unmuted")}'

def isDirectConflict(*args):
	return getDirectConflict(*args) > 0

def isIndirectConflict(*args):
	return getInDirectConflict(*args) > 0

def nbDirectConflict(inputs):
	"""
	"""

	if len(inputs)<2:
		return 0

	### the dict with the device as key and the list of associated apps as value
	Nd = {}
	Kd = {}
	for app,events in inputs.items():
		d = events[0]['device']
		if d not in Nd:
			Nd[d] = [app]
		else:
			Nd[d].append(app)
		Kd[d] = len(events)

	return sum(Kd[d]*(len(Nd[d])-i) for d in Nd for i in range(1,len(Nd[d])))

def nbInDirectConflict(features,inputs):
	"""
	"""
	Nd = dict([(app,events[0]['device']) for app,events in inputs.items()])

	r = 0.0
	for feature,elem in features.items():
		for e in elem:
			device_state,app_event = e
			for a in app_event:
				app,evt = a.split(',')
				d = Nd[app]
				#for c in [(dprim,s) for dprim,s in map(lambda a: a.split(','),device_state) if dprim!=d]:
				#	print('indirect',tuple(sorted([a])),(c[0],c[1]),feature)

				r += len([dprim for dprim,_ in map(lambda a: a.split(','),device_state) if dprim!=d])
	return r
	
def getDirectConflict(input_events,ts):
	### return the direct conflict set

	conflicts = set()

	if len(input_events)<2:
		return conflicts

	### direct conflicts
	for app1,l1 in input_events.items():
		for app2,l2 in [(app,l) for app,l in input_events.items() if app!=app1]:
			### different app but same events set and target device
			#if app1!=app2:
			for v1 in l1:
				for v2 in l2:
					device1,event1,time1=v1['device'],v1['event'],v1['time']
					device2,event2,time2=v2['device'],v2['event'],v2['time']

					### direct conflict when events of different app dedicated for same device!
					if (event1 != event2) and (abs(time2-time1) <= ts) and (device1 == device2):
						v = ('direct',tuple(sorted(["{app}/{event}".format(app=app1,event=event1),"{app}/{event}".format(app=app2,event=event2)])),device1)
						conflicts.add(v)
	
	return conflicts

def getIndirectConflict(input_events,features,current_states):
	### return the indirect conflicts set

	conflicts = set()
	for feature,elem in features.items():
		for e in elem:
			states,events = e
			for a in states:
				device_f,state_f = a.split(',')

				for app,event_list in input_events.items():
					for event in event_list:

						device_e,e,t = event['device'],event['event'],event['time']
				
						### indirect conflict appears when 
						### 1. device of feature and device targeted by the event are different
						### 2. the event sended by the app is in the event feature list
						### 3. the device in the features must by in the states feature.
						current_state_device_f = current_states[device_f]
						evt = "{},{}".format(app,e)

						if device_f != device_e and evt in events and "{},{}".format(device_f,current_state_device_f) in states:
							v = ('indirect',tuple(sorted([evt])),(device_f,current_state_device_f),feature)
							conflicts.add(v)

	return conflicts

def getConflictList(inputs,features,current_states,ts):
	return getDirectConflict(inputs,ts).union(getIndirectConflict(inputs,features,current_states))

# def getConflictList(inputs,features,current_states,ts):
# 	""" Return the list of direct and indirect conflicts as generator.
# 	"""

# 	conflicts = set()

# 	### direct conflicts
# 	for app1,l1 in inputs.items():
# 		for app2,l2 in inputs.items():
# 			### different app but same events set and target device
# 			if app1!=app2:
# 				for v1 in l1:
# 					for v2 in l2:
# 						device1,event1,time1=v1['device'],v1['event'],v1['time']
# 						device2,event2,time2=v2['device'],v2['event'],v2['time']

# 						### direct conflict when events of different app dedicated for same device!
# 						if (event1 != event2) and (abs(time2-time1) <= ts) and (device1 == device2):
# 							v = ('direct',tuple(sorted(["{app}/{event}".format(app=app1,event=event1),"{app}/{event}".format(app=app2,event=event2)])),device1)
# 							conflicts.add(v)

# 	### indirect conflicts
# 	for feature,elem in features.items():
# 		for e in elem:
# 			states,events = e
# 			for a in states:
# 				device_f,state_f = a.split(',')

# 				for app,event_list in inputs.items():
# 					for event in event_list:

# 						device_e,e,t = event['device'],event['event'],event['time']
				
# 						### indirect conflict appears when 
# 						### 1. device of feature and device targeted by the event are different
# 						### 2. the event sended by the app is in the event feature list
# 						### 3. the device in the features must by in the states feature.
# 						current_state_device_f = current_states[device_f]
# 						evt = "{},{}".format(app,e)

# 						if device_f != device_e and evt in events and "{},{}".format(device_f,current_state_device_f) in states:
# 							v = ('indirect',tuple(sorted([evt])),(device_f,current_state_device_f),feature)
# 							conflicts.add(v)

# 	return conflicts

def getActuators(filename:str='rules.txt'):
	""" Return the set od actuators (right part of rules.txt)
	"""

	ACTUATORS = set()
	### rules.txt analysis
	with open(filename,'r') as f:
		### for each line
		for l in f.readlines():
			### for each app
			if '#' not in l:		
				### split with then and and to find the list of actuators
				a_list = l.split('then')[-1].split('and')

				### for each string containing actuators state 
				for s in a_list:
					### actuators
					a = s.split('.')[0].strip()
					ACTUATORS.add(a)

	return ACTUATORS

def getSensors(filename:str='rules.txt'):
	""" Return the set od actuators (left part of rules.txt)
	"""

	SENSORS = set()
	### rules.txt analysis
	with open(filename,'r') as f:
		### for each line
		for l in f.readlines():
			### for each app
			if '#' not in l:
				### split with then and and to find the list of sensors
				s_list = l.split('then')[0].replace('if ','').split('and')
				
				### for each string containing sensors state
				for s in s_list:
					### actuators
					SENSORS.add(s.split('.')[0].strip())

	return SENSORS
	

### Main program
if __name__ == '__main__':
	import random 
	import pprint

	# ### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	# INPUTS = {	"App_Robot":({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
	# 			"App_Phone_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
	# 			"App_RemoteControl_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
	# 		}

	# ### feature is used to indirect conflict detection
	# ### NOISE is the feature that is influenced by only the TV and the Robot device when they are in the state Unmuted and Cleaning
	# ### the indirect conflict appear only when the App_RemoteControl TV send UNMUTE or App_Roboot send CLEAN or APP_Phone_TV send MUTE.
	# FEATURES = {"NOISE":[('TV,Unmuted','Robot,Cleaning'),('App_RemoteControl_TV,UNMUTE', 'App_Robot,CLEAN', 'App_Phone_TV,MUTE')]}

	# ### STATES is the dict which is uded to make a relation between the device and its possible states
	# STATES = {"Robot":("Cleaning","Stopped","Resumed","Paused"), "Phone":("Muted","Unmuted"), "TV":("Muted","Unmuted")}

	### REMEDIOT

	i = 0
	INPUTS = {}
	ACTUATORS_STATES = {}

	### right part of rules.txt
	ACTUATORS = set()

	### left part of rules.txt
	SENSORS = set()

	### devices associated with app
	APPDEVICES = set()

	### rules.txt analysis
	with open('rules.txt','r') as f:
		### for each line
		for l in f.readlines():
			### for each app
			if '#' in l:
				#INPUTS["App_{}".format(i)] = []
				#i+=1
				pass
			else:
				#i+=1
				### split with then and and to find the list of actuators
				a_list = l.split('then')[-1].split('and')

				### split with then and and to find the list of sensors
				s_list = l.split('then')[0].replace('if ','').split('and')
				
				### for each string containing sensors state
				for s in s_list:
					### sensors
					SENSORS.add(s.split('.')[0].strip())

				### for each string containing actuators state 
				for s in a_list:
					i +=1
					### actuators
					a = s.split('.')[0].strip()
					ACTUATORS.add(a)
					APPDEVICES.add(a)

					### ON = 1 / OFF = 0
					boolean = s.split('=')[-1].strip()
					#elem = {"device":f"{a}","event":"ON","time":0.0} if boolean == "1" else {"device":f"{a}","event":"OFF","time":0.0}

					INPUTS[f"{i}"] = ({"device":f"{a}","event":"ON","time":0.0},{"device":f"{a}","event":"OFF","time":0.0})

					#INPUTS[f"App_{i-1}_{a}"] = []
					
					#if elem not in INPUTS[f"{i}"]:# and b not in INPUTS["App_{}".format(i-1)]:
					#	INPUTS[f"{i}"].append(elem)
						#INPUTS["App_{}".format(i-1)].append(b)
					ACTUATORS_STATES[a] = ("1","0")

	# ### inputs is the dict used to make a relation between the app and the events and the target device which have in management
	# INPUTS = {	"App_1":({"device":"wfh","event":"ON","time":0.0},{"device":"text","event":"OFF","time":0.0}),
	# 			"App_2":({"device":"user_away_mode","event":"ON","time":0.0},{"device":"motion","event":"ON","time":0.0},
	# 					{"device":"door","event":"OFF","time":0.0},{"device":"windows","event":"OFF","time":0.0}),
	# 			"App_3":({"device":"windows","event":"ON","time":0.0},),
	# 			"App_4":({"device":"text","event":"ON","time":0.0},),
	# 			"App_5":({"device":"text","event":"ON","time":0.0},),
	# 			"App_6":({"device":"ac","event":"ON","time":0.0},{"device":"heater","event":"ON","time":0.0}),
	# 			"App_7":({"device":"lights","event":"ON","time":0.0},{"device":"lights","event":"OFF","time":0.0},{"device":"vacation_mode","event":"ON","time":0.0}),
	# 			"App_8":({"device":"door","event":"ON","time":0.0},),
	# 			"App_9":({"device":"text","event":"ON","time":0.0},),
	# 			"App_10":({"device":"lights","event":"ON","time":0.0},{"device":"lights","event":"OFF","time":0.0},{"device":"motion","event":"ON","time":0.0},{"device":"motion","event":"OFF","time":0.0})
	# 		}

	FEATURES = {
				'STATIONARITY': ('camera,0','motion,0'),
				'ABSENCE': ('user,0','camera,0','user_away_mode,0','wfh,0'),
				'COOL_WITH_HIGHT_EXTERNAL_TEMP': ('ac,1','windows,0','fan,1'),
				'COOL_WITH_LOW_EXTERNAL_TEMP': ('ac,0','windows,1','fan,0'),
				'HOT_WITH_HIGHT_EXTERNAL_TEMP': ('heater,0','windows,1','fireplace,0'),
				'HOT_WITH_LOW_EXTERNAL_TEMP': ('heater,1','windows,0','fireplace,1'),
				'VENTILATION': ('fan,1','windows,1','door,1'),
				'HUMIDITY': ('fan,0','valve,0'),
				'LUMINATION': ('light,1','lights,1','curtain,1'),
				'ENERGY': ('high_power,0','low_power,1'),
				'CONFORT': ('curtain,0', 'lights,0', 'speaker,0'),
				'SAFETY': ('windows,0', 'camera,1', 'door,0','alarm,1','electric_devices,0')
	}

	FEATURE_RULES = {}

	for f,devices in FEATURES.items():
		T = set()
		for elem in devices:
			d,s = elem.split(',')
			for app,l in INPUTS.items():
				for elem in l:
					if elem['device'] == d:
						if s =='0':
							T.add(f'{app},OFF')
						else:
							T.add(f'{app},ON')

		FEATURE_RULES[f] = [(FEATURES[f],T)]
	
	# {'STATIONARITY': [(('camera,0', 'motion,0'), 
	#					{'21,OFF', '197,OFF', '111,OFF', '108,OFF', '147,OFF', '109,OFF', '107,OFF', '110,OFF', '4,OFF', '23,OFF', '146,OFF', '112,OFF', '5,OFF'})], 
	# 'ABSENCE': [(('user,0', 'camera,0', 'user_away_mode,0', 'wfh,0'), 
	#			{'3,OFF', '115,OFF', '114,OFF', '1,OFF', '197,OFF', '113,OFF', '111,OFF', '214,OFF', '108,OFF', '147,OFF', '28,OFF', '109,OFF', '107,OFF', '110,OFF', '146,OFF', '112,OFF', '5,OFF'})], 
	# 'COOL_WITH_HIGHT_EXTERNAL_TEMP': [(('ac,1', 'windows,0', 'fan,1'), 
	#			{'58,OFF', '138,ON', '126,ON', '61,ON', '72,ON', '116,ON', '125,ON', '78,ON', '100,ON', '55,OFF', '54,OFF', '77,ON', '68,ON', '71,ON', '53,OFF', '74,ON', '75,ON', '170,ON', '178,ON', '76,ON', '194,ON', '117,ON', '13,ON', '143,OFF', '174,ON', '56,OFF', '172,ON', '57,OFF', '66,ON', '7,OFF', '73,ON', '62,ON', '8,OFF'})], 
	# 'COOL_WITH_LOW_EXTERNAL_TEMP': [(('ac,0', 'windows,1', 'fan,0'), 
	# 			{'73,OFF', '78,OFF', '58,ON', '76,OFF', '61,OFF', '170,OFF', '100,OFF', '172,OFF', '116,OFF', '7,ON', '126,OFF', '143,ON', '138,OFF', '125,OFF', '194,OFF', '174,OFF', '55,ON', '56,ON', '77,OFF', '72,OFF', '8,ON', '54,ON', '66,OFF', '74,OFF', '13,OFF', '117,OFF', '178,OFF', '71,OFF', '57,ON', '75,OFF', '68,OFF', '53,ON', '62,OFF'})], 
	# 'HOT_WITH_HIGHT_EXTERNAL_TEMP': [(('heater,0', 'windows,1', 'fireplace,0'), 
	#			{'58,ON', '63,OFF', '70,OFF', '80,OFF', '195,OFF', '60,OFF', '7,ON', '67,OFF', '143,ON', '123,OFF', '176,OFF', '69,OFF', '55,ON', '56,ON', '209,OFF', '8,ON', '54,ON', '14,OFF', '79,OFF', '137,OFF', '101,OFF', '208,OFF', '57,ON', '81,OFF', '53,ON'})], 
	# 'HOT_WITH_LOW_EXTERNAL_TEMP': [(('heater,1', 'windows,0', 'fireplace,1'), 
	#			{'176,ON', '58,OFF', '79,ON', '195,ON', '80,ON', '63,ON', '55,OFF', '54,OFF', '60,ON', '137,ON', '70,ON', '69,ON', '209,ON', '53,OFF', '81,ON', '14,ON', '123,ON', '208,ON', '101,ON', '143,OFF', '56,OFF', '57,OFF', '7,OFF', '67,ON', '8,OFF'})], 
	# 'VENTILATION': [(('fan,1', 'windows,1', 'door,1'), 
	#			{'58,ON', '126,ON', '212,ON', '72,ON', '116,ON', '125,ON', '78,ON', '100,ON', '77,ON', '213,ON', '7,ON', '143,ON', '120,ON', '71,ON', '55,ON', '56,ON', '75,ON', '74,ON', '8,ON', '83,ON', '54,ON', '18,ON', '170,ON', '178,ON', '76,ON', '82,ON', '117,ON', '6,ON', '119,ON', '174,ON', '172,ON', '73,ON', '57,ON', '53,ON', '118,ON'})], 
	# 'HUMIDITY': [(('fan,0', 'valve,0'), 
	#			{'73,OFF', '78,OFF', '129,OFF', '76,OFF', '173,OFF', '149,OFF', '170,OFF', '100,OFF', '172,OFF', '116,OFF', '126,OFF', '134,OFF', '125,OFF', '174,OFF', '77,OFF', '72,OFF', '74,OFF', '117,OFF', '178,OFF', '71,OFF', '141,OFF', '75,OFF', '150,OFF'})], 
	# 'LUMINATION': [(('light,1', 'lights,1', 'curtain,1'), 
	#			{'98,ON', '159,ON', '88,ON', '103,ON', '105,ON', '122,ON', '140,ON', '91,ON', '96,ON', '121,ON', '102,ON', '175,ON', '40,ON', '162,ON', '106,ON', '97,ON', '22,ON', '59,ON', '124,ON', '24,ON', '84,ON', '94,ON', '133,ON', '89,ON', '95,ON', '158,ON', '87,ON', '104,ON', '216,ON', '90,ON', '20,ON', '25,ON', '86,ON', '17,ON', '179,ON', '42,ON', '151,ON', '196,ON', '92,ON', '85,ON', '93,ON', '99,ON', '200,ON', '16,ON'})], 
	# 'ENERGY': [(('high_power,0', 'low_power,1'), 
	#			{'145,OFF', '144,OFF', '193,ON', '64,OFF', '198,ON', '65,OFF'})], 
	#'CONFORT': [(('curtain,0', 'lights,0', 'speaker,0'), 
	#			{'157,OFF', '48,OFF', '42,OFF', '182,OFF', '180,OFF', '215,OFF', '191,OFF', '44,OFF', '43,OFF', '158,OFF', '163,OFF', '151,OFF', '36,OFF', '46,OFF', '186,OFF', '40,OFF', '200,OFF', '45,OFF', '184,OFF', '51,OFF', '161,OFF', '148,OFF', '96,OFF', '190,OFF', '98,OFF', '164,OFF', '169,OFF', '188,OFF', '97,OFF', '47,OFF', '49,OFF'})], 
	#'SAFETY': [(('windows,0', 'camera,1', 'door,0', 'alarm,1', 'electric_devices,0'), 
	#			{'213,OFF', '107,ON', '118,OFF', '58,OFF', '108,ON', '212,OFF', '82,OFF', '120,OFF', '55,OFF', '54,OFF', '6,OFF', '146,ON', '147,ON', '26,OFF', '53,OFF', '38,ON', '109,ON', '110,ON', '83,OFF', '119,OFF', '5,ON', '112,ON', '34,OFF', '143,OFF', '56,OFF', '197,ON', '57,OFF', '7,OFF', '18,OFF', '111,ON', '35,OFF', '8,OFF'})]}

	### pour les conflicts directes, résolution par ordre de priorité des applications.
	### pour les conflicts indirectes, résolution par ordre de priorité des devices.
	### dans remedIoT résiltion par ordre de priorité (utility, safety, energy...) dans le graph.

	### size of the loop used to initialize the state of the devices 
	N = 100

	### list of possible direct and indirect conflicts
	conflicts = set()

	### try with several inital states generated randomly
	for i in range(N):
		current_states = dict((app,random.choice(states)) for app,states in ACTUATORS_STATES.items())
		conflicts.update(getConflictList(INPUTS,FEATURE_RULES,current_states,0.0))	
	
	# print("Actuators (right): ",ACTUATORS)
	# print("Sensors (left):",SENSORS)
	# print(ACTUATORS-SENSORS)

	### number of app
	print("Number of apps {}".format(len(INPUTS)))

	### number of actuators
	print("Number of actuators {}".format(len(ACTUATORS)))

	### number of sensors
	print("Number of sensors {}".format(len(SENSORS)))


	### number of devices
	print("Number of devices {}".format(len(ACTUATORS)+len(SENSORS)))

	### number of direct conflicts
	print("Number of direct conflicts {}".format(len([c for c in conflicts if 'direct' == c[0]])))

	### number of indirect conflicts
	print("Number of indirect conflicts {}".format(len([c for c in conflicts if 'indirect' == c[0]])))

	print([c for c in conflicts if 'direct' == c[0]])	
	#for c in conflicts: 
	#	if 'direct' == c[0]:
	#		print(c)

	#t = ""
	#for i in range(0,len(INPUTS)):
	#	t+= f"Input({i+1},0) != null && "
	#print(t)

	#t = ""
	#for i in range(0,len(INPUTS)):
	#	t+= f"Input({i+1})=('ON','OFF') "
	#print(t)

	#t = {}
	#for a in list(SENSORS)+list(ACTUATORS):
	#for a in list(ACTUATORS):
	#	t[f"{a}"]=('1','0') 

	#print(t)

	#t = {}
	#for i in range(1,137):
#		t[i] = ("ON","OFF")
#	print(t)