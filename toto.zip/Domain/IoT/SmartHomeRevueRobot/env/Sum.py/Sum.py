# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		Sum.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2021-05-31 10:21:14.441692
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class Sum(DomainBehavior):
	''' DEVS Class for the model Sum
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.out = 0.0

		self.initPhase('IDLE',INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''

		for p in self.IPorts:
			msg = self.peek(p, *args)
			if msg:
				v = self.getMsgValue(msg)
				self.out += eval(v[0])

		self.holdIn('SEND',0)

		return self.getState()

	def outputFnc(self):
		''' DEVS output function.
		'''
		return self.poke(self.OPorts[0], Message([float(self.out)], self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.passivate()
		return self.getState()

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
