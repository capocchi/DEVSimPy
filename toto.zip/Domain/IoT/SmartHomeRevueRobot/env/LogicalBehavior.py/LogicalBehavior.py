# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		LogicalBehavior.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2020-10-27 10:27:31.379965
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

import random
import pprint

import fct

### Model class ----------------------------------------------------------------
class LogicalBehavior(DomainBehavior):
	''' DEVS Class for the model LogicalBehavior
	'''

	def __init__(self, eca_states_def= {'Robot':("Stopped","Cleaning","Resumed","Paused"), 'Phone':("Muted","Unmuted"), 'TV':("Muted", "Unmuted")}, 
						eca_inputs_def='Input(1)=("STOP","CLEAN", "RESUME", "PAUSE") Input(2)=("MUTE","UNMUTE") Input(3)=("MUTE","UNMUTE")', 
						features={"NOISE":[('TV,Unmuted','Robot,Cleaning'),('App_RemoteControl_TV,UNMUTE', 'App_Robot,CLEAN', 'App_Phone_TV,MUTE')]},
						threshold=10,
						direct_conflict_flag=True,
						indirect_conflict_flag=True):
		''' Constructor.

			@param eca_inputs_def: possible state of device attached to the device (maybe can be defined in the eca spec)
			@param eca_inputs_def: the eca condition rule to detect conflict
			@param features: association between features and inputs definition
			@param threshold: delta considered for the direct conflict
			@param direct_conflict_flag: detect direct conflict f true
			@param indirect_conflict_flag: detect indirect conflict f true
		'''

		DomainBehavior.__init__(self)

		### local copy
		self.eca_inputs_def = eca_inputs_def
		self.eca_states_def = eca_states_def
		self.features = features

		self.ts = threshold
		self.direct_conflict_flag = direct_conflict_flag
		self.indirect_conflict_flag = indirect_conflict_flag

#		self.Tv = 'Unmuted'
#		self.Rob = 'Stopped'
#		self.Phone = 'Unmuted'

		self.out = {}
		self.app = {}

		self._conflictcond = fct.getPythonConflictCond(self.eca_inputs_def)

		### choice randomly init state for devices
		#self.current_states = {}
		#for app,states in eval(fct.getPythonStates(self.eca_states_def)).items():
		#	self.current_states.update({app:random.choice(states)})

		
		### TODO: to deduce from state variables above
		### inputs is the dict used to make a relation between the app and the events and the target device which have in management
		INPUTS = {	"App_Robot":({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
				"App_Phone_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
				"App_RemoteControl_TV":({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
			}

		### size of the loop used to initialize the state of the devices 
		N = 100

		### list of possible direct and indirect conflicts
		self.conflicts = set()

		### try with several inital states generated randomly
		for i in range(N):
			self.current_states = dict((app,random.choice(states)) for app,states in self.eca_states_def.items())
			self.conflicts.update(fct.getConflictList(INPUTS,self.features,self.current_states,0.0))
		
#		pprint.pprint(conflicts)

		self.initPhase('IDLE',INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''

		### peek message
		msg = self.peek(self.IPorts[0], *args)
		v = self.getMsgValue(msg)

		### update the dict of apps
		self.app = dict(v)

		#Inputs sequences definition
#		App_Rob.ROB_START = Input (1,0) == "Clean"
#		App_Rob.ROB_PAUSE = Input (1,0) == "Pause"
#		App_Rob.ROB_RESUME = Input (1,0) == "Resume"
#		App_Rob.ROB_STOP = Input (1,0) == "Stop"
#		App_Phone_TV.TV_MUTE = Input (2,0) == "mute"
#		App_Phone_TV.TV_UNMUTE = Input (2,0) == "unmute"

		event1 = self.app[1]['event']
		event2 = self.app[2]['event']
		event3 = self.app[3]['event']

		App_Rob_ROB_START = event1 == "CLEAN" if 1 in self.app else False
		App_Rob_ROB_PAUSE = event1 == "PAUSE" if 1 in self.app else False
		App_Rob_ROB_RESUME = event1 == "RESUME" if 1 in self.app else False
		App_Rob_ROB_STOP = event1 == "STOP" if 1 in self.app else False
		App_Phone_TV_TV_MUTE = event2 == "MUTE" if 2 in self.app else False
		App_Phone_TV_TV_UNMUTE = event2 == "UNMUTE" if 2 in self.app else False
		App_RemoteControl_TV_TV_MUTE = event3 == "MUTE" if 3 in self.app else False
		App_RemoteControl_TV_TV_UNMUTE = event3 == "UNMUTE" if 3 in self.app else False

		### conflicts detection
		### TODO conflictcond process
		d = eval(self._conflictcond)
		
		Rob = self.current_states[1]
		Phone = self.current_states[2]
		Tv = self.current_states[3]

		directs = fct.isDirectConflict(v,d,self.ts)
		if directs:
			for d in directs:
				if d not in self.conflicts:
					self.debugger("%f - "%msg.time+str(d))
					self.conflicts.append(d)

		indirects = fct.isIndirectConflict(v,self.features,self.current_states)
		if indirects:
			for d in indirects:
				if d not in self.conflicts:
					self.debugger("%f - "%msg.time+str(d))
					self.conflicts.append(d)

		### indirect
#		if App_Phone_TV_TV_MUTE and Rob == 'Cleaning':
#			t = "('indirect', App\_Phone\_TV/CALLIN],(RobotCleaner,CLEANED))" #Indirect conflict between TV that received MUTE and Robot Cleaner is Cleaning"
#			if t not in self.conflicts:
#				self.debugger("%f - "%msg.time+t)
#				self.conflicts.append(t)
#		elif App_RemoteControl_TV_TV_UNMUTE and Rob == 'Cleaning':
#			t = "('indirect', App\_RemoteControl\_TV/UNMUTE],(RobotCleaner,CLEANED))" #"Indirect conflict between TV that received UNMUTE and Robot Cleaner is Cleaning"
#			if t not in self.conflicts:
#				self.debugger("%f - "%msg.time+t)
#				self.conflicts.append(t)
#		elif App_Rob_ROB_START and (Tv=='Unmuted'):
#			t = "('indirect',[App\_Robot/CLEAN],(TV, UNMUTED))" #"Indirect conflict between Robot cleaner that received CLEAN and TV Cleaner is Unmuted"
#			if t not in self.conflicts:
#				self.debugger("%f - "%msg.time+t)
#				self.conflicts.append(t)
#		elif App_Phone_TV_TV_MUTE and (Tv=='Unmuted'):
#			t = "('indirect',[App\_Phone\_TV/CALLIN],(TV, UNMUTED))" #"Indirect conflict between Phone that received MUTE and TV Cleaner is Unmuted"
#			if t not in self.conflicts:
#				self.debugger("%f - "%msg.time+t)
#				self.conflicts.append(t)
		

#		ON App_Rob.ROB_START IF TV=="Muted" DO Rob="Cleaning" doROB_START;
#		ON App_Rob.ROB_STOP IF True DO Rob = "Stopped" doROB_STOP;
#		ON App_Rob.ROB_PAUSE IF Rob == "Cleaning" DO Rob = "Paused" doROB_PAUSE;
#		ON App_Rob.ROB_RESUME IF Rob == "Paused" DO Rob = "Resumed" doROB_RESUME;
#		ON App_Phone_TV.TV_UNMUTE IF Rob =="Cleaning" || Rob =="Resumed" DO Rob = "Paused" doROB_PAUSE;
#		ON App_Phone_TV.TV_UNMUTE IF True DO tv="Unmuted" doTV_UNMUTE;
#		ON App_Phone_TV.TV_MUTE IF True DO phone="Muted" doTV_MUTE;

		self.out = self.app 

		### default
		self.out[1] = 'STOP'
		self.out[2] = 'MUTE'

		if App_Rob_ROB_START and Tv=='Muted':
			Rob = 'Cleaning'
			self.out[1] = 'CLEAN'
#			self.debugger(str(msg.time)+': app 1: '+self.app[1]+' -> '+self.out[1])

		if App_Rob_ROB_STOP and True:
			Rob = 'Stopped'
			self.out[1] = 'STOP'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])
		
		if App_Rob_ROB_PAUSE and Rob=='Cleaning':
			Rob = 'Paused'
			self.out[1] = 'PAUSE'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])

		if App_Rob_ROB_RESUME and Rob=='Paused':
			Rob = 'Resumed'
			self.out[1] = 'RESUME'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])

		### call in 
		if App_Phone_TV_TV_UNMUTE and (Rob=='Cleaning' or Rob=='Resumed'):
			Rob = 'Paused'
			self.out[1] = 'PAUSE'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])

		### call off 
		if App_Phone_TV_TV_UNMUTE and True:
			Tv = 'Unmuted'
			self.out[2] = 'UNMUTE'
#			self.debugger(str(msg.time)+': app2: '+self.app[2]+' -> '+self.out[2])

		### call in
		if App_Phone_TV_TV_MUTE and True:
			#self.Phone = 'Muted'
			Tv = 'Muted'
			self.out[2] = 'MUTE'

#			self.debugger(str(msg.time)+': app2: '+self.app[2]+' -> '+self.out[2])

		# Temporal Properties
#		LivenessInTime (10,20)
#		NoLostEvent ()

		### Logical properties
		assert self.out[1] != "CLEAN" and self.out[2] != "UNMUTE", self.out

		self.current_states[1] = Rob
		self.current_states[2] = Phone
		self.current_states[3] = Tv

		self.holdIn('SEND',0)
			
	def outputFnc(self):
		''' DEVS output function.
		'''
		for i in self.out:
			try:
				self.poke(self.OPorts[i-1], Message([self.out[i]], self.timeNext))
			except:
#				self.debugger('Need more outputs...')
				pass
	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.passivateIn('IDLE')

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
