# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		SimProcess.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2021-09-03 13:47:40.834259
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

import subprocess

### Model class ----------------------------------------------------------------
class SimProcess(DomainBehavior):
	''' DEVS Class for the model SimProcess
	'''

	def __init__(self, fileName=""):
		''' Constructor.

			@param jar_file : MS4Me package
		'''
		DomainBehavior.__init__(self)

		cmd = " ".join(['java', '-jar', fileName])
		self.process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

		self.out = None

		self.initPhase('IDLE',0.0)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''
		return self.getState()

	def outputFnc(self):
		''' DEVS output function.
		'''
		return self.poke(self.OPorts[0], Message(self.out, self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		
		if process.poll() is None:
			self.out = process.stdout.readline()
			self.holdIn("State", 1.0)
		else:
			self.passivate()
			process.stdout.close()

		return self.getState()

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
