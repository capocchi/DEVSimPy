# import re 
# from collections import deque

# def toPython2(string:str)->str:
# 	#s = string.replace("&&", 'and').replace('||', 'or').replace('!= null', '')
# 	for i,elem in enumerate(getAppInfo(string)):
# 		string = re.sub('[Input\(]+([0-9]+)[,]([0-9]+)[\)]+', '%d in buffer'%i, string)

# 		#s = s.replace("Input%s"%str(tuple(map(int,elem))).replace(" ",''),'%d in buffer'%i)
# 	return string.replace("&&", 'and').replace('||', 'or').replace('null', 'None')

# def occurenceCond(string:str, buffer:{})->str:
# 	### tes if occurence is good
# 	regexp = "[ =!]+(?!Input)([A-Za-z\'\"']+)"
# 	cond = ["(%s in buffer[%d])"%(elem,i+1) for i,elem in enumerate(re.findall(regexp, string)) if elem != 'null']

# 	return " and ".join(cond)

# def getPythonTriggerCond(string:str)->str:

# 	def replace(match):
# 		flow_app_nb = match.group(1)
# 		occurence_nb = match.group(2)
# 		signal = match.group(3)

# 		if str(signal) != 'null':
# 			return '(%s in buffer and buffer[%s].count("%s") >= %d)'%(flow_app_nb, flow_app_nb, signal, int(occurence_nb)+1)
# 		else:
# 			return '(%s in buffer and len(buffer[%s])>0)'%(flow_app_nb,flow_app_nb)
			
# 	cond = re.sub('[Input\(]+([\d]+)[, ]([\d]+)[\)]+[ !=]+[\'\"]?([\w]+)[\'\"]?', replace, string)

# 	return cond.replace("&&", 'and').replace('||', 'or')

	
# def getTriggerInfo(string:str)->tuple:
# 	regexp = '[Input\(]+([\d]+)[, ]([\d]+)[\)]+[ !=]+[\'\"]?([\w]+)[\'\"]?'
# 	for elem in re.findall(regexp, string):
# 		yield elem

# l0 = 'Input(1,0) == "STOP"'
# l1 = 'Input(1,0) != null && Input(2,0) == "STOP" && Input(3,0) == "START"'
# l2 = 'Input(1,0) != null || Input(2,0) != null && Input(3,0) != null'

# #buffer = {1:deque(['STOP','START'],maxlen=100)}

# buffer = {1:deque(['STOP','START'],maxlen=100), 2:deque(['STOP','START'],maxlen=100), 3:deque(['STOP','START'],maxlen=100)}

# print(buffer[1].count('STOP') == 2)

# print(getPythonTriggerCond(l0))
# print(getPythonTriggerCond(l1))
# print(getPythonTriggerCond(l2))

# print(eval(getPythonTriggerCond(l0)))
# print(eval(getPythonTriggerCond(l1)))

# print(list(getTriggerInfo(l0)))
# print(list(getTriggerInfo(l1)))

import pprint, random
import itertools


def getConflictList(inputs,features,current_states,ts):
	""" Return the list of direct and indirect conflicts as generator.
	"""

	conflicts = set()

	### direct conflicts
	for app1,l1 in inputs.items():
		for app2,l2 in inputs.items():
			### different app but same events set and target device
			if app1!=app2:
				for v1 in l1:
					for v2 in l2:
						device1,event1,time1=v1['device'],v1['event'],v1['time']
						device2,event2,time2=v2['device'],v2['event'],v2['time']

						### direct conflict when events of different app dedicated for same device!
						if (event1 != event2) and (abs(time2-time1) <= ts) and (device1 == device2):
							v = ('direct',tuple(sorted(["{app}/{event}".format(app=app1,event=event1),"{app}/{event}".format(app=app2,event=event2)])),device1)
							conflicts.add(v)

	### indirect conflicts
	for feature,elem in features.items():
		for e in elem:
			states,events = e
			for a in states:
				device_f,state_f = a.split(',')

				for app,event_list in inputs.items():
					for event in event_list:

						device_e,e,t = event['device'],event['event'],event['time']
				
						### indirect conflict appears when 
						### 1. device of feature and device targeted by the event are different
						### 2. the event sended by the app is in the event feature list
						### 3. the device in the features must by in the states feature.
						current_state_device_f = current_states[device_f]
						evt = "{},{}".format(app,e)

						if device_f != device_e and evt in events and "{},{}".format(device_f,current_state_device_f) in states:
							v = ('indirect',tuple(sorted([evt])),(device_f,current_state_device_f),feature)
							conflicts.add(v)

	return conflicts

##########################################################################################################################
states_def = {'Robot':('Stopped','Cleaning','Resumed','Paused'), 'Phone':('Muted', 'Unmuted'), 'TV':('Muted', 'Unmuted')}

inputs_def = {1:('STOP','CLEAN', 'RESUME', 'PAUSE'), 2:('MUTE','UNMUTE'), 3:('MUTE','UNMUTE')}

app_def = {'Robot':1, 'Phone':2, 'TV':3}

link_def = {1:'Robot', 2:'TV', 3:'TV'}

features={"NOISE":[(('TV,Unmuted','Robot,Cleaning', 'Robot,Resumed'),{'3,UNMUTE', '1,CLEAN', '1,RESUME', '2,UNMUTE'})]}

state_event_map = {"Robot" : {"STOP":"Stopped", "CLEAN":"Cleaning", "RESUME":"Resumed", "PAUSE":"Paused"}, "TV":{"MUTE":"Muted", "UNMUTE":"Unmuted"}}
##########################################################################################################################

inputs = {}
for k,v in inputs_def.items():
	inputs[str(k)] = []
	for e in v:
		inputs[str(k)].append({"device":link_def[k],"event":e,"time":0.0})

### TODO: to deduce from state variables above
### inputs is the dict used to make a relation between the app and the events and the target device which have in management
#inputs = {	'1':({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
#			'2':({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
#			'3':({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
#}


### list of possible direct and indirect conflicts
total_conflicts = set()

### try with several inital states generated randomly
for i in range(100):
	current_states = dict((app,random.choice(states)) for app,states in states_def.items())
	total_conflicts.update(getConflictList(inputs,features,current_states,0.0))

#pprint.pprint(total_conflicts)

def getConflictDevice(features):
	""" return the 
	"""
	for k,v in features.items():
		for e in v:
			for v in e[0]:
				yield v.split(',')[0]

def getConflictStates(features):
	""" return the 
	"""
	for k,v in features.items():
		for e in v:
			for c in itertools.combinations(e[0],2):
				c = sorted(c)
				if c[0].split(',')[0] != c[1].split(',')[0]:
					yield "-".join(c).replace(',','_')

def getSCXM(states_def, conflictsState):
	"""
	"""

	print(conflictsState)

	feature_device_list = set(getConflictDevice(features))
	states = list(itertools.chain(*states_def.values()))

	### states excluding devices that are not in features
	out1 = []
	for k,v in states_def.items():
		for e in v:
			if k in feature_device_list:
				out1.append(f"{k}_{e}")

	out2 = []
	### all combination of states excluding devices that are not in features
	for c in itertools.combinations(out1,2):
		c= sorted(c)
		if c[0].split('_')[0] != c[1].split('_')[0]:
			out2.append("-".join(c))


	### remove undesired states
	for v in conflictsState:
		if v in out2:
			out2.remove(v)

	#print(out2)
	
	#conflictsState = ['Robot_Cleaning-TV_Unmuted', 'Robot_Resumed-TV_Unmuted']
	#out2 = ['Robot_Stopped-TV_Muted', 'Robot_Stopped-TV_Unmuted', 'Robot_Cleaning-TV_Muted', 'Robot_Resumed-TV_Muted', 'Robot_Paused-TV_Muted', 'Robot_Paused-TV_Unmuted']	


	# ### generate the scxml
	txt = f"""<scxml xmlns="http://www.w3.org/2005/07/scxml" version="1.0" initialstate="{random.choice(out2)}">\n"""

 #  	for state1 in out2:
 #  		for state2 in out2:

	#   		txt += f"""
	#   		<state id={state1}>
	#     		<transition event="{event1}" target="{state2}" >
	#       		{outs}
	#     		</transition>
	#   		</state>
	#   		"""
 #  	#<send event="{event2}" />
	
	txt+=	"""</scxml>"""

	print(txt)

getSCXM(states_def, list(getConflictStates(features)))