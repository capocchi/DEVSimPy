# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		LogicalBehavior3.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2020-10-27 10:27:31.379965
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

import random
import pprint

import fct2
import importlib

### Model class ----------------------------------------------------------------
class LogicalBehavior3(DomainBehavior):
	''' DEVS Class for the model LogicalBehavior3
	'''

	def __init__(self, direct_conflict_flag=True, indirect_conflict_flag=True, strategy=1, ts=0):
		''' Constructor.

			@param direct_conflict_flag: detect direct conflict f true
			@param indirect_conflict_flag: detect indirect conflict f true
			@param strategy: define the resolve rules
		'''

		importlib.reload(fct2)

		DomainBehavior.__init__(self)

		### local copy
		self.strategy = strategy		
		self.direct_conflict_flag = direct_conflict_flag
		self.indirect_conflict_flag = indirect_conflict_flag

		##################################################### define by the user
		self.ts = ts

		self.eca_states_def = {"Robot":("Stopped","Cleaning","Resumed","Paused"), "TV":("Muted", "Unmuted")} 
		self.features={"NOISE":[(('TV,Unmuted', 'Robot,Cleaning', 'Robot,Resumed'),{'3,UNMUTE', '1,CLEAN', '1,RESUME', '2,UNMUTE'})]}
		### inputs is the dict used to make a relation between the app and the events and the target device which have in management
		self.INPUTS = {	'1':({"device":"Robot","event":"STOP","time":0.0},{"device":"Robot","event":"CLEAN","time":0.0},{"device":"Robot","event":"RESUME","time":0.0},{"device":"Robot","event":"PAUSE","time":0.0}), 
				'2':({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0}), 
				'3':({"device":"TV","event":"MUTE","time":0.0},{"device":"TV","event":"UNMUTE","time":0.0})
		}
		
		######################################################

		### list of possible direct and indirect conflicts
		self.total_conflicts = fct2.getDirectConflict(self.INPUTS,self.ts)
		self.total_direct_conflicts = set()
		self.total_indirect_conflicts = set()

		### try with several inital states generated randomly
		N = fct2.nbDirectConflict(self.INPUTS) + fct2.nbInDirectConflict(self.features, self.INPUTS)
		while(len(self.total_conflicts) != N):
			self.current_states = dict((app,random.choice(states)) for app,states in self.eca_states_def.items())
			self.total_conflicts.update(fct2.getIndirectConflict(self.INPUTS,self.features, self.current_states))

		### populate the direct and indirect
		for c in self.total_conflicts:
			if 'direct' == c[0]:
				self.total_direct_conflicts.add(c)
			else:
				self.total_indirect_conflicts.add(c)

		self.nb_total_direct_conflicts = len(self.total_direct_conflicts)
		self.nb_total_indirect_conflicts = len(self.total_indirect_conflicts)

		### number of app
#		print(f"Number of apps {len(self.INPUTS)}")

		### number of direct conflicts
#		print(f"Number of direct conflicts {len(self.total_direct_conflicts)}")

		### number of indirect conflicts
#		print(f"Number of indirect conflicts {len(self.total_indirect_conflicts)}")

		pprint.pprint(self.total_conflicts)

		### output def
		nbActuators = self.eca_states_def.keys()
		self.out = dict(zip(nbActuators, range(len(nbActuators))))

		self.app = {}

		self.initPhase('IDLE',INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''
		
		### peek message
		msg = self.peek(self.IPorts[0], *args)
		v = self.getMsgValue(msg)

		### update the dict of apps
		self.app = dict(v)

		v = dict([(a,[b]) for a,b in v])

		### search direct conflicts
		directs = fct2.getDirectConflict(v, self.ts)
		indirects = fct2.getIndirectConflict(v, self.features, self.current_states)

		if self.strategy == 1:
			self.resolveConflicts1(directs,indirects)
		elif self.strategy == 2:
			self.resolveConflicts2(directs,indirects)
		else:
			pass

		self.holdIn('SEND',0)
	
	def resolveConflicts2(self, directs, indirects):
		""" Resolves conflict from ECA rules
		"""

		
		#### Update rates
		a = len(self.total_direct_conflicts) > 0
		b = len(self.total_indirect_conflicts) > 0 

		### if direct conflicts have been founded
		if directs and a:
			self.total_direct_conflicts -= directs
		
		### if indirect conflicts have been founded
		if indirects and b:
			self.total_indirect_conflicts -= indirects
		
		#####################################################

		event1 = self.app.get(1,{}).get('event',None)
		event2 = self.app.get(2,{}).get('event',None)
		event3 = self.app.get(3,{}).get('event',None)

		App_Rob_ROB_START = event1 == "CLEAN" if 1 in self.app else False
		App_Rob_ROB_PAUSE = event1 == "PAUSE" if 1 in self.app else False
		App_Rob_ROB_RESUME = event1 == "RESUME" if 1 in self.app else False
		App_Rob_ROB_STOP = event1 == "STOP" if 1 in self.app else False
		App_Phone_TV_TV_MUTE = event2 == "MUTE" if 2 in self.app else False
		App_Phone_TV_TV_UNMUTE = event2 == "UNMUTE" if 2 in self.app else False
		App_RemoteControl_TV_TV_MUTE = event3 == "MUTE" if 3 in self.app else False
		App_RemoteControl_TV_TV_UNMUTE = event3 == "UNMUTE" if 3 in self.app else False

		Rob = self.current_states['Robot']
#		Phone = self.current_states['Phone']
		Tv = self.current_states['TV']

		### default
		self.D = {'Robot':'STOP', 'TV':'MUTE'}

		### rules
		if App_Rob_ROB_START and Tv=='Muted':
			Rob = 'Cleaning'
			self.D['Robot'] = 'CLEAN'
#			self.debugger(str(msg.time)+': app 1: '+self.app[1]+' -> '+self.out[1])

		if App_Rob_ROB_STOP and True:
			Rob = 'Stopped'
			self.D['Robot'] = 'STOP'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])
		
		if App_Rob_ROB_PAUSE and Rob=='Cleaning':
			Rob = 'Paused'
			self.D['Robot'] = 'PAUSE'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])

		if App_Rob_ROB_RESUME and Rob=='Paused':
			Rob = 'Resumed'
			self.D['Robot'] = 'RESUME'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])

		### call in 
		if App_Phone_TV_TV_UNMUTE and (Rob=='Cleaning' or Rob=='Resumed'):
			Rob = 'Paused'
			self.D['Robot'] = 'PAUSE'
#			self.debugger(str(msg.time)+': app1: '+self.app[1]+' -> '+self.out[1])

		### call off 
		if App_Phone_TV_TV_UNMUTE and True:
			Tv = 'Unmuted'
			self.D['TV'] = 'UNMUTE'
#			self.debugger(str(msg.time)+': app2: '+self.app[2]+' -> '+self.out[2])

		### call in
		if App_Phone_TV_TV_MUTE and True:
			#self.Phone = 'Muted'
			Tv = 'Muted'
			self.D['TV'] = 'MUTE'

#			self.debugger(str(msg.time)+': app2: '+self.app[2]+' -> '+self.out[2])

		# Temporal Properties
#		LivenessInTime (10,20)
#		NoLostEvent ()

		### Logical properties
#		assert self.D['Robot'] != "CLEAN" and self.D['TV'] != "UNMUTE", self.D

		self.current_states['Robot'] = Rob
#		self.current_states['Phone'] = Phone
		self.current_states['TV'] = Tv

	def resolveConflicts1(self, directs, indirects):
		""" Resolves conflict automatically and randomly by analysing directs and indirect conflicts list.
		"""

		state_event_map = {"Robot" : {"STOP":"Stopped", "CLEAN":"Cleaning", "RESUME":"Resumed", "PAUSE":"Paused"}, "TV":{"MUTE":"Muted", "UNMUTE":"Unmuted"}}
		a = len(self.total_direct_conflicts) > 0
		b = len(self.total_indirect_conflicts) > 0 

		self.D = {}

		### if direct conflicts have been founded
		if directs:
			### resolution rule: send to a device, the last one app event with the first command (('direct', ('216/ON', '85/OFF'), 'light') -> ('light',ON)) 
			for c in directs:
				self.D.update({c[-1]:c[1][0].split('/')[1]})
				self.debugger(f"Direct conflict {c} detected!")
			if a:
				self.total_direct_conflicts -= directs
		

		### if indirect conflicts have been founded
		if indirects:
			indirects_sorted = sorted(set([c[1] for c in indirects]))
			self.debugger(f"InDirect conflict {sorted(set([c for c in indirects]))} detected")
			for i in range(len(indirects_sorted)):
				app1_id,e1 = indirects_sorted[i][0].split(',')
				try:
					app2_id,e2 = indirects_sorted[i+1][0].split(',')
				except Exception:
					app_id,e = indirects_sorted[-1][0].split(',')
					device_app = self.INPUTS[str(app_id)][0]['device']
					self.D.update({device_app:random.choice([a for a in state_event_map[device_app].keys() if a != e])})
				else:
					if app1_id != app2_id:
						device_app = self.INPUTS[str(app1_id)][0]['device']
						### update of the direct conflict dict with the indirect one because indirect conflict resolve the same direct conflict when direct ansd indirect conflcit occur on the same device.
						self.D.update({device_app:random.choice([a for a in state_event_map[device_app].keys() if a != e1])})
			if b:
				self.total_indirect_conflicts -= indirects
		
		### update current_states
		for _,values in self.app.items():
			self.current_states[values['device']] = state_event_map[values['device']][values['event']]

	def outputFnc(self):
		''' DEVS output function.
		'''
		a = round(100*len(self.total_direct_conflicts)/self.nb_total_direct_conflicts,2)
		b = round(100*len(self.total_indirect_conflicts)/self.nb_total_indirect_conflicts,2)

		### direct/indirect conflict rates
		self.poke(self.OPorts[0], Message([a], self.timeNext))
		self.poke(self.OPorts[1], Message([b], self.timeNext))

		for d,i in self.out.items():
			if d in self.D:
				e = self.D[d]
#				self.debugger(f"Resolving (direct/indirect) conflicts of {[str(j)+'/'+self.app[j]['event'] for j in self.app if self.app[j]['device']==d]} apps with the app {i+1} for {d}: {e} is sended to {d}")
				self.debugger(f"Resolving (direct/indirect) last detected conflict: {e} is sended to {d}")
			elif i+1 in self.app:
				e = self.app[i+1]['event']
				self.debugger(f"No direct conflict: {e} is sended to {d} by the {i+1} app")
			else:
				e = None
				self.debugger(f"Error: device {d}, app {i+1}")

			if e and len(self.OPorts)>2:
				self.poke(self.OPorts[i+2], Message([e], self.timeNext))
		
		return {}
		
	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.passivateIn('IDLE')

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
