import random
import math

class SampleFromDistribution:

	def __init__(self):
		pass
	
	def getMean(self)->float:
		return 1.0

	def getSample(self,lambd:float=None)->float:
		sample = random.random()
		if lambd:
			return -(1/lambd)*math.log(sample)
		else: 
			return sample

	def getMeanNVariance(self,numSamples:int)->[float]:
		pmf = [self.getSample() for i in range(numSamples)]

		avg = sum(pmf)/len(pmf)
		
		var = 0
		for el in pmf:
			delta = el - avg
			var += delta * delta
		
		var = var / len(pmf)
		coeff = var/(avg*avg)
		
		return [avg, var]

if __name__ == '__main__':
	pass