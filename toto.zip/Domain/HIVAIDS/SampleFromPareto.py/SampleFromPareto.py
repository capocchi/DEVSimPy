
from SampleFromDistribution import SampleFromDistribution

import math

class SampleFromPareto(SampleFromDistribution):
		
	def __init__(self,alpha:float=None):
		SampleFromDistribution.__init__(self)
		
		if alpha:
			self.alpha= alpha
		else:
			self.alpha = 1

	def getSample(self)->float:
		return 1/math.pow(random.random(), 1/self.alpha)
	
	def getMean(self)->float:
		self.alpha