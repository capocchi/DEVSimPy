
from SampleFromDistribution import SampleFromDistribution

import numpy as np

class SampleFromNormal(SampleFromDistribution):

	def __init__(self, mean:float=None, sigma:float=None):
			
		SampleFromDistribution.__init__(self)

		self.mean = mean if mean else 1
		self.sigma = sigma if sigma else 1
		
	def getSample(self)->float:
		return  self.mean+self.sigma*np.random.normal()
	
	def getMean(self)->float:
		return self.mean

if __name__ == '__main__':
	pass