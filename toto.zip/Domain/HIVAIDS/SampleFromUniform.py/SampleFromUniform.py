
from SampleFromDistribution import SampleFromDistribution

import random

class SampleFromUniform(SampleFromDistribution):

	def __init__(self, lower, upper):
		SampleFromDistribution.__init__(self)

		if lower and upper:
			self.lower=lower
			self.upper = upper
		else:		
			self.lower = 0
			self.upper = 1

	def getSample(self)->float:
		return  self.lower+(self.upper-self.lower)*random.random()
	

	def getMean(self)->float:
		return (self.upper+self.lower)/2