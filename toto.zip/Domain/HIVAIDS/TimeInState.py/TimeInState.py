
class TimeInState:

    def __init__(self, StateName:str='', CountInState:int=0.0, ElapsedTime:float=0.0):
        self.StateName = StateName
        self.CountInState = CountInState
        self.ElapsedTime = ElapsedTime

    def setStateName(self, StateName:str)->None:
        self.StateName = StateName

    def getStateName(self)->str:
        return self.StateName

    def setCountInState(self, CountInState:int)->None:
        self.CountInState = CountInState

    def getCountInState(self)->int:
        return self.CountInState

    def setElapsedTime(self,ElapsedTime:float)->None:
        self.ElapsedTime = ElapsedTime

    def getElapsedTime(self)->float:
        return self.ElapsedTime

    def __str__(self)->str:
        str = "TimeInState"
        str += "\n\tStateName: " + self.StateName;
        str += "\n\tCountInState: " + self.CountInState;
        str += "\n\tElapsedTime: " + self.ElapsedTime;
        return str