class TimeInfo(object):
	"""
	"""

	def __init__(self, t:str=None, m:float=1.0, l:float=0.0, u:float=1.0, s:float=1.0, a:float=1.0):
		""" Constructor.
		"""

		self._type = t
		self._mean = m
		self._lower = l
		self._upper = u
		self._sigma = s
		self._alpha = a

	### getter
	def getType(self)->str:
		return self._type

	def getMean(self)->float:
		return self._mean

	def getLower(self)->float:
		return self._lower

	def getUpper(self)->float:
		return self._upper

	def getSigma(self)->float:
		return self._sigma

	def getAlpha(self)->float:
		return self._alpha

	### setter
	def setType(self, t:str)->None:
		self._type = t

	def setMean(self,m:float)->None:
		self._mean = m

	def setLower(self,l=float)->None:
		self._lower = l

	def setUpper(self,u:float)->None:
		self._upper = u

	def setSigma(self,s=float)->None:
		self._sigma = s

	def setAlpha(self,a:float)->None:
		self._alpha = a