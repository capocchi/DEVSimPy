
from ContinuousTimeMarkov import ContinuousTimeMarkov
from TransitionInfo import TransitionInfo
from TimeInfo import TimeInfo

class MarkovTransition(object):
	"""
 	"""

	def __init__(self, state:str="", succ:str="", succs:list=[], probs:list=[], type:str="", params:list=[]):
		""" Constructor
		"""
		### define Continuous Markov Chain
		ctm = ContinuousTimeMarkov()

		### add Transition info
		if probs == []: probs = [-1] 

		ctm.addTransitionInfo(state, succs, probs)
		
		### define the transition info obj from ctm
		self.transitionInfo = ctm.getTransitionInfoFor(state,succ)

		### define time info
		ti = TimeInfo()
		
		if (type != '' and params != []):
			ti.setType(type)
			if type == 'Exponential':
				ti.setMean(params[0])
			elif type == 'Uniform':
				ti.setLower(params[0])
				ti.setUpper(params[1])
			elif type == 'Normal':
				ti.setMean(params[0])
				ti.setSigma(params[1])

		### time info setting
		self.transitionInfo.setTInfo(ti)
		
	### setter
	def setTransitionInfo(self, transitionInfo:TransitionInfo)->None:
		self.transitionInfo = transitionInfo

	### getter
	def getTransitionInfo(self)->TransitionInfo:
		return self.transitionInfo

	### override
	def __str__(self)->str:
		return f"MarkovTransition \n\tTransitionInfo: {self.transitionInfo}"

	###
	def transferTransitionInfo(self, ctm:ContinuousTimeMarkov)->None:
		ti = self.getTransitionInfo()
		if (ti == None):
			return
		else:
			tim = ctm.getTransitionInfoFor(ti.getStartState(), ti.getEndState())
			if (tim == None):return
			else:
				print(type(ti))
				if (ti.getProbValue() >= 0):
					tim.setProbValue(ti.getProbValue())
				if (ti.getTInfo().getType() != None):
					tim.setTInfo(ti.getTInfo())