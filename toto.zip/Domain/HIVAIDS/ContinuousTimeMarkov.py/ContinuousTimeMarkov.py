
import random
import math
import sys
from lxml import etree

#from MarkovTransition import MarkovTransition
from TransitionInfo import TransitionInfo
from TimeInfo import TimeInfo
from TimeInState import TimeInState

class ContinuousTimeMarkov(object):
	"""docstring for ContinuousTimeMarkov"""

	def __init__(self):

		self.Seed = 2349991
		self.Rand = random.randint(0,self.Seed)

		self.mm = None
		self.timeToNextEvent = 0.0
		self.initialState =""

		self.nextState = ""
		self.AccLifeTime = 0
		self.AvgLifeTime = 0
		self.TimeInStateList= []
		self.TransitionInfoList = []
		self.endStateSet = []
		self.isOutput = False

	def getRand(self):
		return self.Rand

	def getAccLifeTime(self)->float:
		return self.AccLifeTime

	def setAccLifeTime(self, accLifeTime:float)->None:
		self.AccLifeTime = accLifeTime

	def incCount(self, tm:TimeInState)-> None:
		ct = tm.getCountInState() + 1
		tm.setCountInState(ct)

	def updateElapsedTime(self, tm:TimeInState, e:float)-> None:
		ct = tm.getElapsedTime() + e
		tm.setElapsedTime(ct)

	def getTimeInState(self, state:str)->TimeInState:
		for tm in self.TimeInStateList:
			if tm.getStateName() == state:
				return tm
		return None

	def getSuccs(self, state:str)->[str]:
		return [ti.getEndState() for ti in self.getTransitionInfoFor(state)]

	def getTransitionInfoList(self)->[TransitionInfo]:
		for i in self.TransitionInfoList: 
			yield i

	def getTimeInStateList(self)->[TimeInState]:
		return self.TimeInStateList

	def setTimeInStateList(self, timeInStateList:[TimeInState])->None:
		self.TimeInStateList = timeInStateList

	def setTimeToNextEvent(self, timeToNextEvent:float=0.0)->None:
		self.timeToNextEvent = timeToNextEvent

	def setOutput(self,isOutput:bool)->None:
		self.isOutput = isOutput

	def getOutput(self)->bool:
		return self.isOutput

	def addTimeInStateList(self, tm:TimeInState)->None:
		self.TimeInStateList.append(tm)

	def getNextState(self)->str:
		return self.nextState

	def setNextState(self,nextState:str)->None:
		self.nextState = nextState

	def getStates(self)->str:
		return "".join([ti.getStartState() for ti in self.TransitionInfoList])

	def getIndex(self,state:str)->int:
	    for i,v in enumarate(self.indexStates()):
	        if v == state:
	            return i
	    return -1

	def indexStates(self)->[str]:
		return sorted(self.getStates())

	def getSuccs(self,state:str)->[str]:
	    return [ti.getEndState() for ti in self.getTransitionInfoFor(state)]
	    
	def getProbs(self,state:str)->[float]:
	    probs = [0.0]*len(self.getStates())
	    
	    for i in range(len(self.TransitionInfoList)):
	        ti = self.TransitionInfoList[i]
	        if ti.getStartState()==state:
	            index = self.getIndex(ti.getEndState())
	            probs[index] = ti.getProbValue()

	    s = sum(probs)
	    
	    if s<1:
	    	probs[self.getIndex(state)] = 1 - s
	    
	    return probs

	def normalFactor(self,state:str):
		sum = 0
		for succ in self.getSuccs(state):
			if succ != state:
				ti = self.getTransitionInfoFor(state, succ)
				sum += ti.getProbValue()

		return sum

	def getTimeToNextEvent(self)->float:
		return self.timeToNextEvent

	### Get a sample time from time information in TransitionInfo (9/17/2017 cseo)
	def timeToNextEventFromTI(self, *args)->float:
		if len(args)==3:
			state, succ, norm = args
			if(state == succ): 
				return sys.float_info.max
			else:
				ti = self.getTransitionInfoFor(state, succ)
				if(ti.getType() == None): return ti.getSample(norm)
		   
				return ti.getSample()
		else:
			l = args[0]
			sample = random.uniform(0, 1)
			return -(1 / l) * math.log(sample)

	def fillTransitionInfoList(self,fname:str)->None:
	    
	    tree = etree.parse(fname)
	    startStates = [ StartState.text for StartState in tree.xpath("/ProbDEVS/TransitionInfo/StartState")]
	    endStates = [ EndState.text for EndState in tree.xpath("/ProbDEVS/TransitionInfo/EndState")]
	    probValue = [ float(ProbValue.text) for ProbValue in tree.xpath("/ProbDEVS/TransitionInfo/ProbValue")]
	    
	    timeInfoType = [ Type.text for Type in tree.xpath("/ProbDEVS/TransitionInfo/TimeInfo/Type")]
	    timeInfoLower = [ float(Lower.text) for Lower in tree.xpath("/ProbDEVS/TransitionInfo/TimeInfo/Lower")]
	    timeInfoUpper = [ float(Upper.text) for Upper in tree.xpath("/ProbDEVS/TransitionInfo/TimeInfo/Upper")]
	    timeInfoMean = [ float(Mean.text) for Mean in tree.xpath("/ProbDEVS/TransitionInfo/TimeInfo/Mean")]
	    timeInfoSigma = [ float(Sigma.text) for Sigma in tree.xpath("/ProbDEVS/TransitionInfo/TimeInfo/Sigma")]
	    timeInfoAlpha = [ float(Alpha.text) for Alpha in tree.xpath("/ProbDEVS/TransitionInfo/TimeInfo/Alpha")]

	    for i,tp in enumerate(timeInfoType):
	    	ti = TransitionInfo(startStates[i],endStates[i],probValue[i])
	    	ti.setTInfo(TimeInfo(tp, timeInfoMean[i], timeInfoLower[i], timeInfoUpper[i], timeInfoSigma[i], timeInfoAlpha[i]))
	    	self.TransitionInfoList.append(ti)

	def getTransitionInfoFor1(self,state:str)->TransitionInfo:
	    for ti in self.getTransitionInfoList():
	        if ti.getStartState() == state:
	            yield ti

	def getTransitionInfoFor(self,state:str, succ:str=None)->TransitionInfo:
		if succ:
			for ti in self.getTransitionInfoFor1(state):
				if (ti.getEndState() == succ):
					return ti
			return None
		else:
			return [ti for ti in self.getTransitionInfoList() if ti.getStartState() == state]

	def getMeanValue(self,state:str, succ:str)->float:
		if state == succ: 
			return -1.0
		else:
			ti = self.getTransitionInfoFor(state, succ)
			if not ti.getType(): return -1.0
			return ti.getMean()

	def addTransitionInfo(self,state:str="", successors:list=[], probabilities:list=[])->None:
		for i,succ in enumerate(successors):
			ti = TransitionInfo(state,succ,probabilities[i])
			self.TransitionInfoList.append(ti)
		