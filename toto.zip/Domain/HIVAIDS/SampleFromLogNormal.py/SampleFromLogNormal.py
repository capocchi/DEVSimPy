
from SampleFromDistribution import SampleFromDistribution

import math
import numpy as np

class SampleFromLogNormal(SampleFromDistribution):

	def __init__(self, mean:float=None, sigma:float=None, coef:float=None):
		
		SampleFromDistribution.__init__(self)

		if mean and sigma:
			self.mean = mean
			self.sigma = sigma
		elif coef:
			self.mean=0
			self.sigma=math.sqrt(lath.log(coef+1))
		else:
			self.mean=1
			self.sigma=1

	def getSample(self)->float:
		return math.exp(self.mean + self.sigma*np.random.normal())
	
	def getMean(self)->float:
		return self.mean
	
	def computeCoeff(self)->float:
		return math.exp(self.sigma*self.sigma)-1
	
	def computeSigma(self, coef:float=None)->float:
		return math.sqrt(math.log(self.coef+1))