
from SampleFromDistribution import SampleFromDistribution

import math, random

class SampleFromExponential(SampleFromDistribution):

	def __init__(self,mean:float=None):
		SampleFromDistribution.__init__(self)

		self.mean = mean if mean else 1
		
	def getSample(self)->float:
		return -self.mean*math.log(random.random())
	
	def getMean(self)->float:
		return self.mean

if __name__ == '__main__':
	pass