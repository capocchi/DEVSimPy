
from TimeInfo import TimeInfo
from SampleFromDistribution import SampleFromDistribution
from SampleFromUniform import SampleFromUniform
from SampleFromNormal import SampleFromNormal
from SampleFromExponential import SampleFromExponential
from SampleFromLogNormal import SampleFromLogNormal
from SampleFromPareto import SampleFromPareto

class TransitionInfo(object):
	"""
	"""
	def __init__(self, start:str='start', end:str='end', prob:float=-1.0, ti:TimeInfo=None)->None:
		""" Constructor
		"""

		self.StartState = start
		self.EndState = end
		self.ProbValue = prob

		self.TInfo = ti if ti else TimeInfo()

		self.sfd = None

		self.setSampleFromDistribution()

	### getter
	def getEndState(self)->str:
		return self.EndState

	def getStartState(self)->str:
		return self.StartState

	def getProbValue(self)->float:
		return self.ProbValue

	def getTInfo(self)->TimeInfo:
		return self.TInfo

	### setter
	def setEndState(self,v:str)->None:
		self.EndState = v

	def setStartState(self,v:str)->None:
		self.StartState = v

	def setProbValue(self, v:float)->None:
		self.ProbValue = v
	
	def setTInfo(self,ti:TimeInfo)->None:
		self.TInfo = ti
		self.setSampleFromDistribution()

	def setSampleFromDistribution(self):
		type = self.TInfo.getType()
		if type==None:
			self.sfd = SampleFromDistribution()
		elif type.upper()=="uniform":
			self.sfd = SampleFromUniform(self.TInfo.getLower(),self.TInfo.getUpper())
		elif type.upper() == "normal":
			self.sfd = SampleFromNormal(self.TInfo.getMean(),self.TInfo.getSigma())
		elif type.upper() == "exponential":
			self.sfd = SampleFromExponential(self.TInfo.getMean())
		elif type.upper() == "logNormal":
			self.sfd = SampleFromLogNormal(self.TInfo.getMean(),self.TInfo.getSigma())
		elif type.upper() == "pareto":
			self.sfd = SampleFromPareto(self.TInfo.getAlpha())
		
	### override
	def __str__(self)->str:
		t = self.TInfo.getType()
		m = self.TInfo.getMean()
		l = self.TInfo.getLower()
		u = self.TInfo.getUpper()
		a = self.TInfo.getAlpha()
		s = self.TInfo.getSigma()

		return f"StartState:\t{self.StartState}\nEndState:\t{self.EndState}\nProbValue:\t{self.ProbValue}\nTimeInfo:\n\tType:\t{t}\n\tLower:\t{l}\n\tUpper:\t{u}\n\tMean:\t{m}\n\tSigma:\t{s}\n\tAlpha:\t{a}\n"

if __name__ == '__main__':

	transitionInfo = TransitionInfo()
	ti = transitionInfo.getTInfo()
	#ti.setType('Exponential')
	print(transitionInfo)
