# -*- coding: utf-8 -*-

"""
Name : TripahseGen.py
Brief descritpion : Tri phase generator atomic model
Author(s) : Laurent CAPOCCHI (capocchi@univ-corse.fr)
Version :  1.0
Last modified : 21/03/09
GENERAL NOTES AND REMARKS:
GLOBAL VARIABLES AND FUNCTIONS:
"""

from math import pi, sqrt, sin, cos
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

#    ======================================================================    #

class TriphaseGen(DomainBehavior):
	"""	Model atomique de la fonction triphase.
	"""

	###
	def __init__(self, a=[0,0,0], f=50, phi=[0,0,0], k=20, m=["QSS2","QSS2","QSS2"]):
		"""	Constructeur.
		"""
		DomainBehavior.__init__(self)

		assert(len(a)==len(phi)==len(m))

		# Declaration des variables d'ï¿½tat (actif tout de suite)
		self.state = { 'status': 'ACTIVE', 'sigma': 0}
		# Local copy
		self.a = a
		self.f = f
		self.phi = phi
		self.k = k							# nombre de points calculï¿½s
		self.m = m

		self.w = 2*3.14159*self.f								# pulsation
		self.dt = 1/float(self.f)/float(self.k) 					# pas de calcul en temps

	###
	def intTransition(self):

		# Changement d'ï¿½tat (inactif pendant dt)
		self.changeState(sigma=self.dt)
		return self.state

	###
	def outputFnc(self):

		# Liste envoyï¿½e dans le message de sortie
		for i in range(len(self.OPorts)):
			L = [self.a[i]*sin(self.w*self.timeNext+self.phi[i]),0.0,0.0]

			if(self.m=="QSS2"):
				L[1]=self.a[i]*self.w*cos(self.w*self.timeNext+self.phi[i])
			elif(self.m=="QSS3"):
				L[1]=self.a[i]*self.w*cos(self.w*self.timeNext+self.phi[i])
				L[2]=-self.a[i]*pow(self.w,2)*sin(self.w*self.timeNext+self.phi[i])/2

			# envoie du message le port de sortie
			self.poke(self.OPorts[i], Message(L,self.timeNext))

	###
	def timeAdvance(self):
		return self.state['sigma']

	###
	def changeState( self, status = 'IDLE',sigma = INFINITY):
		self.state['status']=status
		self.state['sigma']=sigma

	###
	def __str__(self):return "TriphaseGen"
