# -*- coding: utf-8 -*-

import sys

from iexfinance.stocks import Stock
tsla = Stock(sys.argv[1])
print(tsla.get_price())
