# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		GetIndexFromYahoo.py
 Model description:     Index generator based on iexfinace module
 Authors:       		capocchi_l
 Organization:  		SPE Lab. UMR CNRS 6134
 Current date & time:   2018-03-27 13:28:27.569000
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

import pip
import importlib

def import_package(package):
	try:
		importlib.import_module(package)
		
	except ImportError:
		import_pip()
		
		sys.stdout.write("Install %s form pip\n"%package)
		pip.main(['install', package])

	finally:
		globals()[package] = importlib.import_module(package)

import_package("urllib3")
import_package("bs4")

#import urllib3

from bs4 import BeautifulSoup
import re
import os
import numpy as np

### Model class ----------------------------------------------------------------
class GetIndexFromYahoo(DomainBehavior):
	''' DEVS Class for the model Index
	'''

	def __init__(self, index=('CAC40', '^DJI', '^IXIC'), step=0):
		''' Constructor.
			@param index : yahoo finance indexes
		'''
		DomainBehavior.__init__(self)

		self.index = index[0]
		self.step = step
		
		self.D = {'^IXIC':"https://finance.yahoo.com/quote/%5EIXIC/?guccounter=1", 
					'CAC40':"https://finance.yahoo.com/quote/%5EFCHI?p=^FCHI",
					'^DJI':"https://finance.yahoo.com/quote/%5EDJI?p=^DJI",
					'CL=F':"https://finance.yahoo.com/quote/CL=F?p=CL=F",
					'GC=F': "https://finance.yahoo.com/quote/GC=F?p=GC=F",
					'SI=F':"https://finance.yahoo.com/quote/SI=F?p=SI=F",
					'EURUSD=X':"https://finance.yahoo.com/quote/EURUSD=X?p=EURUSD=X",
					'^TNX':"https://finance.yahoo.com/quote/%5ETNX?p=^TNX",
					'^VIX':"https://finance.yahoo.com/quote/%5EVIX?p=^VIX",
					'GBPUSD=X':"https://finance.yahoo.com/quote/GBPUSD=X?p=GBPUSD=X",
					'JPY=X':"https://finance.yahoo.com/quote/JPY=X?p=JPY=X",
					'BTC=X':"https://finance.yahoo.com/quote/BTC-USD?p=BTC-USD",
					'^CMC200':"https://finance.yahoo.com/quote/%5ECMC200?p=^CMC200",
					'^FTSE':"https://finance.yahoo.com/quote/%5EFTSE?p=^FTSE",
					'^N225':"https://finance.yahoo.com/quote/%5EN225?p=^N225",
					'NIO':"https://finance.yahoo.com/quote/NIO?p=NIO"}

		self.initPhase('SEND',0)

	def outputFnc(self):
		''' DEVS output function.
		'''
		
		http = urllib3.PoolManager()

		response = http.request('GET', self.D[self.index])
		soup = BeautifulSoup(response.data, "lxml")


		# find a list of all span elements
		t = soup.find_all('span', {'class' : 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})[0]

		
		try:
			value = float(re.search('>(.*)</', str(t), re.IGNORECASE).group(1).replace(',',''))
		except:
			value = float(re.search('-->(.*)<!--', str(t), re.IGNORECASE).group(1).replace(',',''))
		
		return self.poke(self.OPorts[0], Message([self.index, value, 0.1], self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		if self.step != 0:
			self.holdIn('SEND',self.step)
		else:
			self.passivateIn('IDLE')

		return self.state

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
