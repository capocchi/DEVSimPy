# -*- coding: utf-8 -*-

from iexfinance import get_available_symbols

print(get_available_symbols(output_format='pandas')[:2])
