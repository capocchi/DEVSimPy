# -*- coding: utf-8 -*-
import random
import os
import numpy as np
from collections import deque
import datetime

import tensorflow as tf

#if tensorflow.__version__ >= '2.0':
from tensorflow.python.keras.models import Sequential, model_from_yaml, load_model
from tensorflow.python.keras.layers import Dense
from tensorflow.python.keras.optimizers import Adam

# https://keon.io/deep-q-learning/
# https://github.com/keon/deep-q-learning/blob/master/dqn.py

class DQNAgent:
    def __init__(self, state_size, action_size, g=0.95, eps=1.0, a=0.01):
        self.state_size = state_size
        self.action_size = action_size
        self.gamma = g     # discount rate
        self.epsilon = eps # exploration rate
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = a
        self.memory = deque(maxlen=2000)
        self.model = self._build_model()

        #log_dir="out" #os.path.join("out",datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
        #self.tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=log_dir, histogram_freq=1)
        #self.tensorboard_callback.set_model(self.model)

        self.state_action_map = self.actions = self.states = None

    def _build_model(self):
        # Neural Net for Deep-Q learning Model
        model = Sequential()
        model.add(Dense(24, input_dim=self.state_size, activation='relu'))
        model.add(Dense(24, activation='relu'))
        model.add(Dense(self.action_size, activation='linear'))
        model.compile(loss='mse',
                      optimizer=Adam(lr=self.learning_rate), metrics=['accuracy'])
        return model

    def setStateActionMap(self, A, actions, states):
        self.state_action_map = A
        self.actions = actions
        self.states = states

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((np.array([state]), action, reward, np.array([next_state]), done))

    def act(self, state):
        if np.random.rand() <= self.epsilon:
            #a = np.random.randint(0,len(self.state_action_map[str(state)]))
            #return self.actions.index(self.state_action_map[str(state)][a]['action'])
            return random.randrange(self.action_size)
        act_values = self.model.predict(np.array([state]))
        return np.argmax(act_values[0])  # returns action

    def replay(self, batch_size):
        batch_size = min(batch_size, len(self.memory))

        minibatch = random.sample(self.memory, batch_size)

        inputs = np.zeros((batch_size, self.state_size))
        outputs = np.zeros((batch_size, self.action_size))

        for i, (state, action, reward, next_state, done) in enumerate(minibatch):
            target = self.model.predict(state)[0]
            if done:
                target[action] = reward
            else:
                target[action] = reward + self.gamma * np.max(self.model.predict(next_state))

            inputs[i] = state
            outputs[i] = target

        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

        return self.model.fit(inputs, outputs, epochs=1, verbose=0, batch_size=batch_size)
        #minibatch = random.sample(self.memory, batch_size)

        #for state, action, reward, next_state, done in minibatch:
        #    target = reward
        #    #print(state, action, reward, next_state, done)
        #    if not done:
        #        target = reward + self.gamma*np.amax(self.model.predict(next_state)[0])
        #    
        #    target_f = self.model.predict(state)
        #    target_f[0][action] = target

        #    training_history = self.model.fit(state, target_f, epochs=1, verbose=0)# callbacks=[self.tensorboard_callback])
        #print("Average test loss/acc: %f/%f"%(np.average(training_history.history['loss']),np.average(training_history.history['acc'])), end='\r')

        #if self.epsilon > self.epsilon_min:
        #    self.epsilon *= self.epsilon_decay

        #return training_history

    def get_score(self,X,Y):
        scores = self.model.evaluate(X, Y, verbose=0)
        print("%s: %.2f%%" % (self.model.metrics_names[1], scores[1]*100), end='\r')

    def load(self, name):
        ''' https://machinelearningmastery.com/save-load-keras-deep-learning-models/
        '''
        # load model
        self.model = load_model(os.path.join(os.getcwd(),'out',name))
        print("Model loaded from disk")

    def save(self, name):
        # save model and architecture to single file
        self.model.save(os.path.join(os.getcwd(),'out',name))
        print("Saved model to disk")