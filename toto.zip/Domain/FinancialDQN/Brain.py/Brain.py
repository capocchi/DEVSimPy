
import math
import os
import numpy as np

#import seaborn as sns
#import matplotlib.pyplot as plt

import importlib
cntk = importlib.util.find_spec("cntk")
tf = importlib.util.find_spec("tensorflow")
found_cntk = cntk is not None
found_tf = tf is not None

if found_cntk:
    import cntk as C

    # https://www.cntk.ai/pythondocs/CNTK_203_Reinforcement_Learning_Basics.html
    # Select the right target device when this notebook is being tested:
    if 'TEST_DEVICE' in os.environ:
        if os.environ['TEST_DEVICE'] == 'cpu':
            C.device.try_set_default_device(C.device.cpu())
        else:
            C.device.try_set_default_device(C.device.gpu(0))

    class Brain:
        def __init__(self, nb_state, nb_action, H, lr = 0.00025):

            self.nb_state = nb_state
            self.nb_action = nb_action

            self.H = H # hidden layer size
            self.lr = lr
            
            self.model, self.trainer, self.loss = self._create()
            # self.model.load_weights("cartpole-basic.h5")

        def _create(self):
            
            observation = C.sequence.input_variable(self.nb_state, np.float32, name="s")
            q_target = C.sequence.input_variable(self.nb_action, np.float32, name="q")

            # Following a style similar to Keras
            l1 = C.layers.Dense(self.H, activation=C.relu)
            l2 = C.layers.Dense(self.nb_action, activation=C.sigmoid)
            unbound_model = C.layers.Sequential([l1, l2])
            model = unbound_model(observation)

            # loss='mse'
            loss = C.squared_error(model, q_target)
            #loss = C.reduce_mean(C.square(model - q_target), axis=0)
            #meas = C.reduce_mean(C.square(model - q_target), axis=0)

            # writers
            progress_printer = C.logging.progress_print.ProgressPrinter(first=0, freq=10)
            logging_callbacks = [progress_printer]

            # optimizer
            lr_schedule = C.learning_parameter_schedule(self.lr)
            learner = C.sgd(model.parameters, lr_schedule, gradient_clipping_threshold_per_sample=10)
            trainer = C.Trainer(model, (loss), learner, progress_writers=logging_callbacks)
            #trainer = C.Trainer(model, (loss, meas), learner, progress_writers=logging_callbacks)

            # CNTK: return trainer and loss as well
            return model, trainer, loss

        def train(self, x, y, epoch=1, verbose=0):
            #self.model.fit(x, y, batch_size=64, nb_epoch=epoch, verbose=verbose)
            arguments = dict(zip(self.loss.arguments, [x,y]))
            updated, results = self.trainer.train_minibatch(arguments, outputs=[self.loss.output])

        def plot(self, path=""):
            C.logging.graph.plot(self.model, 'model.png')
            
        def predict(self, s):
            return self.model.eval([s])
elif found_tk:

    import tensorflow as tf
    from tensorflow import keras
    import random
    import numpy as np
    import datetime as dt
    import math

    class Brain:
        def __init__(self, nb_state, nb_action, H, lr = 0.00025):

            self.nb_state = nb_state
            self.nb_action = nb_action

            self.H = H # hidden layer size
            self.lr = lr
            
            self.model, self.trainer, self.loss = self._create()
            # self.model.load_weights("cartpole-basic.h5")

        def _create(self):
            
            observation = C.sequence.input_variable(self.nb_state, np.float32, name="s")
            q_target = C.sequence.input_variable(self.nb_action, np.float32, name="q")

            # Following a style similar to Keras
            l1 = C.layers.Dense(self.H, activation=C.relu)
            l2 = C.layers.Dense(self.nb_action, activation=C.sigmoid)
            unbound_model = C.layers.Sequential([l1, l2])
            model = unbound_model(observation)

            # loss='mse'
            loss = C.squared_error(model, q_target)
            #loss = C.reduce_mean(C.square(model - q_target), axis=0)
            #meas = C.reduce_mean(C.square(model - q_target), axis=0)

            # writers
            progress_printer = C.logging.progress_print.ProgressPrinter(first=0, freq=10)
            logging_callbacks = [progress_printer]

            # optimizer
            lr_schedule = C.learning_parameter_schedule(self.lr)
            learner = C.sgd(model.parameters, lr_schedule, gradient_clipping_threshold_per_sample=10)
            trainer = C.Trainer(model, (loss), learner, progress_writers=logging_callbacks)
            #trainer = C.Trainer(model, (loss, meas), learner, progress_writers=logging_callbacks)

            # CNTK: return trainer and loss as well
            return model, trainer, loss

        def train(self, x, y, epoch=1, verbose=0):
            #self.model.fit(x, y, batch_size=64, nb_epoch=epoch, verbose=verbose)
            arguments = dict(zip(self.loss.arguments, [x,y]))
            updated, results = self.trainer.train_minibatch(arguments, outputs=[self.loss.output])

        def plot(self, path=""):
            C.logging.graph.plot(self.model, 'model.png')
            
        def predict(self, s):
            return self.model.eval([s])

else:
    print('Brain class not load:')