# -*- coding: utf-8 -*-

import random

import importlib
cntk = importlib.util.find_spec("cntk")
tf = importlib.util.find_spec("tensorflow")
found_cntk = cntk is not None
found_tf = tf is not None

if found_cntk:
    class Memory:   # stored as ( s, a, r, s_ )

        def __init__(self, capacity):
            self.samples = []
            self.capacity = capacity

        def add(self, sample):
            self.samples.append(sample)

            if len(self.samples) > self.capacity:
                self.samples.pop(0)

        def sample(self, n):
            n = min(n, len(self.samples))
            return random.sample(self.samples, n)

elif found_tf:
    class Memory:
        def __init__(self, max_memory):
            self._max_memory = max_memory
            self._samples = []

        def add_sample(self, sample):
            self._samples.append(sample)
            if len(self._samples) > self._max_memory:
                self._samples.pop(0)

        def sample(self, no_samples):
            if no_samples > len(self._samples):
                return random.sample(self._samples, len(self._samples))
            else:
                return random.sample(self._samples, no_samples)

        @property
        def num_samples(self):
            return len(self._samples)
else:
    print("Memory class not load!")