__all__ = [
	'Observer',
	'Strategy',
	'Memoize',
	'Strategy',
	'Factory'
 ]
