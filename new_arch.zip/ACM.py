# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          		ACM.py
 Model description:     <description>
 Authors:       		Laurent
 Organization:  		<your organization>
 Current date & time:   2020-10-27 10:27:31.379965
 License:       		GPL v3.0
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class ACM(DomainBehavior):
	''' DEVS Class for the model ACM
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.app = {}

		self.initPhase('IDLE',INFINITY)

	def extTransition(self, *args):
		''' DEVS external transition function.
		'''
		msg = self.peek(self.IPorts[0], *args)
		v = self.getMsgValue(msg)

		self.app.update(v)
		
		app_robot = 0 in self.app
		app_phone_tv = 1 in self.app
		app_remote_tv = 2 in self.app

		### Detection of the conflict
		#if (robot and self.app[0][0] in ('START','CLEAN')) and (phone and self.app[1][0]=='UNMUTE') or (tv and self.app[2][0]=='UNMUTE'):
		if (app_phone_tv and self.app[1][0]=='UNMUTE') and (app_remote_tv and self.app[2][0]=='MUTE'):
			self.holdIn('CONFLICT',0)
			self.debugger('Conflict at time %d'%msg.time)
			### Resolving the conflict
			if app_robot and self.app[0][0] in ('START','CLEAN'):
				self.out = {0:['PAUSE',0,0], 2:['MUTE',0,0]}
			else:
				self.out = {1:['MUTE',0,0], 2:['MUTE',0,0]}
		else:
			self.holdIn('SEND',0)
			for i in self.app:
				self.out[i] = self.app[i]

	def outputFnc(self):
		''' DEVS output function.
		'''
		if 0 in self.out:
			self.poke(self.OPorts[0], Message(self.out[0], self.timeNext))
		if 1 in self.out:
			self.poke(self.OPorts[1], Message(self.out[1], self.timeNext))

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		self.passivateIn('IDLE')

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.getSigma()

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
