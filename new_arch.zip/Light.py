# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------------
 Name:          Light.py
 Model:         Light component
 Authors:       L. Capocchi
 Organization:  SPE UMR CNRS 6134
 Date:          2014-11-17
 License:       
-------------------------------------------------------------------------------
"""

### Specific import ------------------------------------------------------------
from DomainInterface.DomainBehavior import DomainBehavior
from DomainInterface.Object import Message

### Model class ----------------------------------------------------------------
class Light(DomainBehavior):
	''' DEVS Class for Light model
	'''

	def __init__(self):
		''' Constructor.
		'''
		DomainBehavior.__init__(self)

		self.state = {	'status': 'ON', 'sigma':INFINITY}

	def extTransition(self):
		''' DEVS external transition function.
		'''
		msg = self.peek(self.IPorts[0])

		if hasattr(self.blockModel, 'frame'):
			try:
				self.blockModel.frame.panel.state = msg.value[0]
				self.blockModel.frame.panel.DisplayNext()
			except Exception, info:
				pass

		self.state['sigma'] = INFINITY

	def outputFnc(self):
		''' DEVS output function.
		'''
		pass

	def intTransition(self):
		''' DEVS internal transition function.
		'''
		pass

	def timeAdvance(self):
		''' DEVS Time Advance function.
		'''
		return self.state['sigma']

	def finish(self, msg):
		''' Additional function which is lunched just before the end of the simulation.
		'''
		pass
