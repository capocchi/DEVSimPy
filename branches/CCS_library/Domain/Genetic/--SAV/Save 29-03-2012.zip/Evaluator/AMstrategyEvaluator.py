#MODULES DEVS
from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

class AMstrategiesEvaluator(DomainBehavior):

#-----------------------------------------------------

    def __init__(self, listWeight=[0.5,0.5]):
        DomainBehavior.__init__(self)
        self.dicoExternalResult = {}
        self.listWeight = listWeight
        self.state['sigma'] = INFINITY
        self.state['action'] = "WAIT POPULATION"

#-----------------------------------------------------

    def extTransition(self):
        #1- RECEPTION DE LA PREMIERE GENERATION
        if self.state['action'] == "WAIT POPULATION":
            print "EVALUATOR : RECEPTION DUNE POPULATION"
            if self.peek(self.IPorts[0]):
                msg = self.peek(self.IPorts[0])
                self.population = msg.value[0]
                self.state['sigma'] = 0
                            
        #2- RECEPTION DES RESULTAT ET CALCUL PONDERE
        if self.state['action'] == "WAIT RESPONSE":
            print "EVALUATOR : RECEPTION DUNE REPONSE"
            for i in range(1,len(self.IPorts)):
                if self.peek(self.IPorts[i]):
                    msg = self.peek(self.IPorts[i])
                    results = msg.value[0]
                    self.dicoExternalResult[i] = results
                    
            self.state['sigma'] = INFINITY
            print self.dicoExternalResult

            #TOUS LES RESULTATS SONT COLLECTES
            if len(self.dicoExternalResult) == len(self.IPorts) - 1:
                print "EVALUATOR : TOUS LES MODELS ONT REPONDU"
                self.state['action'] = "EVALUATIONS FINISH"
                self.state['sigma'] = 0
            
        
#-----------------------------------------------------
        
    def outputFnc(self):
        #1- DEMANDES DEVALUATION
        if self.state['action'] == "WAIT POPULATION":
            print "EVALUATOR : ENVOI DES DEMANDES DEVALUATION"
            msg = Message()
            msg.value = [self.population, 0.0, 0.0]
            msg.time = self.timeNext
            for i in range(len(self.OPorts)-1):
                print "EVALUATOR : DEMANDE EVALUATION NUM ",i
                self.poke(self.OPorts[i],msg)

        #2- ENVOI DUNE POPULATION EVALUEE
        if self.state['action'] == "EVALUATIONS FINISH":
            print "EVALUATOR : CALCUL MOYENNE PONDEE"
            self.makePopulationGlobalEvaluation()
            
            print "EVALUATOR : EVALUATION TERMINEE TRANSMISSION SELECTIONNEUR"
##            print self.population #DEBUG
##            self.population.sortPopulation()
##            print "triee"
##            print self.population
            print self.population
            msg = Message()
            msg.value = [self.population, 0.0, 0.0]
            msg.time = self.timeNext
            self.poke(self.OPorts[len(self.OPorts)-1],msg)
            
#-----------------------------------------------------

    def intTransition(self):
        #ON A ENVOYER LES DEMANDES DEVALUATION
        if self.state['action'] == "WAIT POPULATION":
            self.state['action'] = "WAIT RESPONSE"
            print "EVALUATOR : PASSAGE EN ATTENTE DE REPONSE"
        
        #ON A TRANSMIS LA POPULATION EVALUEE
        if self.state['action'] == "EVALUATIONS FINISH":
            self.dicoExternalResult = {}
            self.population = []
            self.state['action'] = "WAIT POPULATION"

        self.state['sigma'] = INFINITY

#-----------------------------------------------------

    def timeAdvance(self):
        return self.state['sigma']

#-----------------------------------------------------

    def __str__(self):
        return "AMstrategiesEvaluator"

#-----------------------------------------------------

    def makePopulationGlobalEvaluation(self):
        for i in range(len(self.population.individuals)):
            notes = []
            resu = 0
            for val in self.dicoExternalResult.values():
                #print "valeurs", val
                notes.append(val[i])
            #print "les notes de l'individu sont :", notes
            
            for j in range(len(self.listWeight)):
                resu += notes[j] * self.listWeight[j]

            #AJOUTER LA NOTE A LINDIVIDU
            ############################
            #print "La note de lindividu ", i, "est :", resu
            self.population.individuals[i].setEvaluation(resu)
            #Meilleure conception self.population.setEval(numindiv, eval)
            #si la classe indiv est modifie il faudra juste modifier pop
                
        

