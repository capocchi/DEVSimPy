import random
#MODULES DEVS
from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

class AMfalseCoverageModel(DomainBehavior):


    def __init__(self,nameEval="COUVERTURE", minValue=10, maxValue=10):
        DomainBehavior.__init__(self)

        self.minValue = minValue
        self.maxValue = maxValue
        
        self.Evalname = nameEval
        self.state = {'sigma':INFINITY }
        self.evaluationList = []

    def extTransition(self):
        print self.Evalname," : RECEPTION"
        msg = self.peek(self.IPorts[0])
        self.population = msg.value[0]
        for individual in self.population.individuals:
            self.evaluationList.append(self.simulate(individual))
        print self.Evalname," : EVALUATION TERMINEE"

        self.state['sigma'] = 0
        
    def outputFnc(self):
        print self.Evalname," : ENVOI RESULTATS EVALUATION"
        msg = Message()
        msg.value = [self.evaluationList, 0.0, 0.0]
        msg.time = self.timeNext
        self.poke(self.OPorts[0],msg)

    def intTransition(self):
        self.state['sigma'] = INFINITY
        self.evaluationList = []

    def timeAdvance(self):
        return self.state['sigma']
    
    def __str__(self):
        return "AMfalseCoverageModel"

    def simulate(self, individual):
        return random.randint(self.minValue, self.maxValue)
        
