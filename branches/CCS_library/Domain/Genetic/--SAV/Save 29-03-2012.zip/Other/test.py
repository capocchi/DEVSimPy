import random

class Pe():
    
    def __init__(self):
        self.age = random.randint(0,90)
        
    def __str__(self):
        return str(self.age)
        
l1 = [Pe(),Pe(),Pe(),Pe()]
l2 = l1[:3]

for p in l1:
    print p
print "--"
for p in l2:
    print p

l2[0] = Pe()
print "MODIF"

for p in l1:
    print p
print "--"
for p in l2:
    print p