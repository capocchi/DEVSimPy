#MODULES DEVS
from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

class AMclassiqueMutator(DomainBehavior):

#-----------------------------------------------------

    def __init__(self, mutationPercent=20):
        DomainBehavior.__init__(self)
        self.mutationPercent = mutationPercent
        self.state['sigma'] = INFINITY

#-----------------------------------------------------

    def extTransition(self):
        print "MUTATOR : RECEPTION DUNE POPULATION"
        self.population = self.getReceivedMessage()
        self.makeMutationProcess()
        self.state['sigma'] = 0

#-----------------------------------------------------

    def outputFnc(self):
        print "MUTATOR : ENVOIS DE LA NOUVELLE POPULATION MUTEE"
        print self.population
        self.sendMessage(0,self.population)


#-----------------------------------------------------

    def intTransition(self):
        self.state['sigma'] = INFINITY


#-----------------------------------------------------

    def timeAdvance(self):
        return self.state['sigma']

#-----------------------------------------------------

    def __str__(self):
        return "AMclassiqueMutator"

#-----------------------------------------------------

#GESTION DE LA MUTATION

    def makeMutationProcess(self):
        #SELECTION DES REPRODUCTEURS
        for individual in self.population.individuals:
            if individual.reproductor == False:
                individual.mutateIndividual(self.mutationPercent)
    
#SIMPLIFICATION DU CODE DE GESTION DES MESSAGES

    def getReceivedMessage(self):
        #VERIFIER AVEC LC SI EXT SE DECLANCHE UNE SEULE FOIS LORS DE PLUSIEURS MESSAGE
        for port in self.IPorts :
            if self.peek(port):
                msg = self.peek(port)
        return msg.value[0]

    def sendMessage(self,NumPort, message):
        msg = Message()
        msg.value = [message]
        msg.time = self.timeNext
        self.poke(self.OPorts[NumPort], msg)

