#MODULES DEVS
from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message
from Domain.Genetic.Librairie.CrossOver import CrossOverHalfAndHalf
from Domain.Genetic.Librairie.CrossOver import CrossOverOneOfTwo

class AMreproductor(DomainBehavior):

#-----------------------------------------------------

    def __init__(self):
        DomainBehavior.__init__(self)
        self.state['sigma'] = INFINITY

#-----------------------------------------------------

    def extTransition(self):
        print "REPRODUCTOR : RECEPTION DUNE POPULATION"
        self.population = self.getReceivedMessage()
        self.makeReproductionProcess()
        self.state['sigma'] = 0

#-----------------------------------------------------

    def outputFnc(self):
        print "REPRODUCTOR : ENVOIS DE LA NOUVELLE POPULATION"
        print self.population
        self.sendMessage(0,self.population)


#-----------------------------------------------------

    def intTransition(self):
        self.state['sigma'] = INFINITY


#-----------------------------------------------------

    def timeAdvance(self):
        return self.state['sigma']

#-----------------------------------------------------

    def __str__(self):
        return "AMreproductor"

#-----------------------------------------------------

#GESTION DE LA FUSION

    def makeReproductionProcess(self):
        #SELECTION DES REPRODUCTEURS
        reproductors = filter(lambda individual: individual.reproductor, self.population.individuals) #LIST DES MEILLEURS INDIVIDUS
        reproductors.reverse()
        print "REPRODUCTOR : LE NOMBRE DE REPRODUCTEUR EST", len(reproductors)
        children = self.makeChildren(reproductors)
        print "REPRODUCTOR :", len(children), "NOUVEAUX INDIVIDUS ONT ETE CREES"
        #DEBUG[BEGIN]
#        print self.population
#        for indi in children:
#            print indi
        #DEBUG[END]
        print "REPRODUCTOR : INTEGRATION DES NOUVEAUX INDIVIDUS DANS LA POPULATION"
        self.population.integrateChildren(children)
#        print self.population

    def makeChildren(self, parents):
        children = []
        for i in range(0, len(parents)-1, 2):
#            print "creation de lenfant de", i, "et ", i+1
            crossOver = CrossOverOneOfTwo(parents[i], parents[i+1]) #ENFANT PERE ET MERE
            children.append(crossOver.createChild())
#            print "creation de lenfant de", i+1, "et ", i
            crossOver = CrossOverOneOfTwo(parents[i+1], parents[i]) # ENFANT MERE ET PERE
            children.append(crossOver.createChild())
        return children #LISTE DES ENFANTS



#SIMPLIFICATION DU CODE DE GESTION DES MESSAGES

    def getReceivedMessage(self):
        #VERIFIER AVEC LC SI EXT SE DECLANCHE UNE SEULE FOIS LORS DE PLUSIEURS MESSAGE
        for port in self.IPorts :
            if self.peek(port):
                msg = self.peek(port)
        return msg.value[0]

    def sendMessage(self,NumPort, message):
        msg = Message()
        msg.value = [message]
        msg.time = self.timeNext
        self.poke(self.OPorts[NumPort], msg)

