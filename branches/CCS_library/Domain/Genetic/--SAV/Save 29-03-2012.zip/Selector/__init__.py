__all__ = [
	    "AMstrategySelector"
  ]
