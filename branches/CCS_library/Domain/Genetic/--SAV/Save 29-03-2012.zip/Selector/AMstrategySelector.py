import time #DEBUG

#MODULES DEVS
from DomainInterface.DomainBehavior import DomainBehavior
from Domain.Basic.Object import Message

class AMstrategiesSelector(DomainBehavior):

#-----------------------------------------------------

    def __init__(self):
        DomainBehavior.__init__(self)
        self.state['sigma'] = INFINITY

#-----------------------------------------------------

    def extTransition(self):
        print "SELECTOR : RECEPTION DUNE POPULATION"
        self.population = self.getReceivedMessage()
#        print self.population

        print "SELECTOR : TRI DES INDIVIDUS"
        self.population.clearSelection()
        self.population.sortPopulation()


        for i in range(len(self.population.individuals)/2, len(self.population.individuals)):
            self.population.individuals[i].becomeReproductor()

        self.state['sigma'] = 0

#-----------------------------------------------------

    def outputFnc(self):
        print "SELECTOR : ENVOIS DE LA POPULATION (SELECTIONNE ET MORTS)"
        print self.population
        time.sleep(1) #DEBUG
        self.sendMessage(0,self.population)


#-----------------------------------------------------

    def intTransition(self):
        self.state['sigma'] = INFINITY


#-----------------------------------------------------

    def timeAdvance(self):
        return self.state['sigma']

#-----------------------------------------------------

    def __str__(self):
        return "AMstrategiesSelector"

#-----------------------------------------------------

    def getReceivedMessage(self):
        #VERIFIER AVEC LC SI EXT SE DECLANCHE UNE SEULE FOIS LORS DE PLUSIEURS MESSAGE
        for port in self.IPorts :
            if self.peek(port):
                msg = self.peek(port)
        return msg.value[0]

    def sendMessage(self,NumPort, message):
        msg = Message()
        msg.value = [message]
        msg.time = self.timeNext
        self.poke(self.OPorts[NumPort], msg)
