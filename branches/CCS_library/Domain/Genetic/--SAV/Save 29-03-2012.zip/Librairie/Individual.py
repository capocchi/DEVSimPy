import random
# CREATION DUN INDIVIDU

class IndividualFactory:

    def __init__(self, seize, geneFactory):
        self.seize = seize
        self.geneFactory = geneFactory

    def makeIndividual(self):
        #print "***createIndividual***"
        ADN = []
        for i in range(self.seize):
            ADN.append(self.geneFactory.makeGene())
        return Individual(ADN)

class Individual:

    def __init__(self, ADN, evaluation=0, reproductor=False):
        self.ADN = ADN
        self.evaluation = evaluation
        self.reproductor = reproductor

    def __str__(self):
        result = "-"
        for gene in self.ADN:
            result += str(gene)
        result += ":::"
        result += str(self.evaluation)
        result += "reproductor:"
        result += str(self.reproductor)
        result += "\n"
        return result

    def setEvaluation(self, evaluation):
        self.evaluation = evaluation

    def becomeReproductor(self):
        self.reproductor = True

    def mutateIndividual(self, percent):
        numberGeneToMutate = len(self.ADN) * percent / 100
        listIndexToUpdate = random.sample(range(len(self.ADN)), numberGeneToMutate)
        print len(listIndexToUpdate), "genes vont etre mutes"
        print "aux indices suivant", listIndexToUpdate
        
        for i in listIndexToUpdate:
            self.ADN[i] = self.ADN[i].factory.makeGene()

